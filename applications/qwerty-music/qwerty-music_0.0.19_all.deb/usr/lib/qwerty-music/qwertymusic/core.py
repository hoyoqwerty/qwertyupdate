# -*- coding: utf-8 -*-
"""qwerty-music の、画面に関係しない部分(曲の情報・ライブラリ・再生の順番・歌詞・設定)。"""
import json
import os
import random
import re
import time

try:
    import mutagen
except Exception:  # mutagen が無くても、ファイル名だけで動く
    mutagen = None

AUDIO_EXT = {".mp3", ".flac", ".ogg", ".oga", ".opus", ".m4a", ".mp4", ".aac", ".wav", ".wma", ".ape", ".wv", ".aiff", ".aif", ".mka"}
COVER_NAMES = ("cover", "folder", "front", "album", "albumart", "artwork")
COVER_EXT = (".jpg", ".jpeg", ".png", ".webp")


def data_dir():
    d = os.environ.get("QWERTY_MUSIC_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share", "qwerty-music")
    os.makedirs(d, exist_ok=True)
    return d


def is_audio(path):
    return os.path.splitext(path)[1].lower() in AUDIO_EXT


def fmt_time(sec):
    """秒 → 「3:05」「1:02:03」。分かれば、桁をそろえる。"""
    try:
        s = int(round(float(sec)))
    except (TypeError, ValueError):
        return "-:--"
    if s < 0:
        s = 0
    h, r = divmod(s, 3600)
    m, s = divmod(r, 60)
    return "%d:%02d:%02d" % (h, m, s) if h else "%d:%02d" % (m, s)


def natural_key(s):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", s or "")]


def _first(v):
    if isinstance(v, (list, tuple)):
        return str(v[0]) if v else ""
    return "" if v is None else str(v)


def _num(v):
    m = re.match(r"\s*(\d+)", _first(v))
    return int(m.group(1)) if m else 0


def read_tags(path):
    """曲の情報を読む。読めない項目は、空(題名はファイル名)になる。"""
    base = os.path.splitext(os.path.basename(path))[0]
    t = {"path": path, "title": base, "artist": "", "album": "", "albumartist": "", "track": 0, "disc": 0,
         "year": "", "genre": "", "duration": 0.0, "bitrate": 0, "format": os.path.splitext(path)[1][1:].upper()}
    if mutagen is None:
        return t
    try:
        f = mutagen.File(path, easy=True)
    except Exception:
        f = None
    if f is None:
        return t
    try:
        tags = f.tags or {}
        g = lambda k: _first(tags.get(k)) if hasattr(tags, "get") else ""
        t["title"] = g("title") or base
        t["artist"] = g("artist")
        t["album"] = g("album")
        t["albumartist"] = g("albumartist")
        t["track"] = _num(g("tracknumber"))
        t["disc"] = _num(g("discnumber"))
        t["year"] = g("date")[:4]
        t["genre"] = g("genre")
    except Exception:
        pass
    try:
        t["duration"] = float(f.info.length)
        t["bitrate"] = int(getattr(f.info, "bitrate", 0) or 0)
    except Exception:
        pass
    return t


def find_folder_cover(path):
    d = os.path.dirname(path)
    try:
        names = os.listdir(d)
    except OSError:
        return None
    low = {n.lower(): n for n in names}
    for stem in COVER_NAMES:
        for ext in COVER_EXT:
            if stem + ext in low:
                return os.path.join(d, low[stem + ext])
    return None


def read_cover(path):
    """曲に埋め込まれた絵(なければ、同じフォルダーの cover.jpg など)を、バイト列で返す。無ければ None。"""
    if mutagen is not None:
        try:
            f = mutagen.File(path)
            if f is not None:
                pics = getattr(f, "pictures", None)          # FLAC
                if pics:
                    return bytes(pics[0].data)
                tags = f.tags
                if tags is not None:
                    if hasattr(tags, "getall"):               # ID3
                        for a in tags.getall("APIC"):
                            return bytes(a.data)
                    if "covr" in tags:                        # MP4
                        c = tags["covr"]
                        if c:
                            return bytes(c[0])
                    if "metadata_block_picture" in tags:      # Ogg / Opus
                        import base64
                        from mutagen.flac import Picture
                        return bytes(Picture(base64.b64decode(tags["metadata_block_picture"][0])).data)
        except Exception:
            pass
    fc = find_folder_cover(path)
    if fc:
        try:
            with open(fc, "rb") as fh:
                return fh.read()
        except OSError:
            return None
    return None


# ---------- 歌詞 ----------
_LRC = re.compile(r"\[(\d+):(\d+(?:[.:]\d+)?)\]")


def parse_lrc(text):
    """LRC 形式 → [(ミリ秒, 行)]。時刻が無い文章は [(None, 行)]。"""
    out, plain = [], []
    for raw in (text or "").splitlines():
        line = raw.rstrip("\r\n")
        stamps = list(_LRC.finditer(line))
        if stamps:
            body = _LRC.sub("", line).strip()
            for m in stamps:
                sec = float(m.group(2).replace(":", "."))
                out.append((int((int(m.group(1)) * 60 + sec) * 1000), body))
        elif re.match(r"\[[a-zA-Z]+:.*\]\s*$", line.strip()):
            continue    # [ti:...] などの情報行
        else:
            plain.append(line)
    if out:
        return sorted(out, key=lambda x: x[0])
    while plain and not plain[0].strip():
        plain.pop(0)
    while plain and not plain[-1].strip():
        plain.pop()
    return [(None, l) for l in plain]


def read_lyrics(path):
    base = os.path.splitext(path)[0]
    for ext in (".lrc", ".LRC", ".txt"):
        p = base + ext
        if os.path.isfile(p):
            for enc in ("utf-8-sig", "cp932", "latin-1"):
                try:
                    with open(p, encoding=enc) as fh:
                        return parse_lrc(fh.read())
                except (UnicodeDecodeError, OSError):
                    continue
    if mutagen is not None:
        try:
            f = mutagen.File(path)
            tags = f.tags if f is not None else None
            if tags is not None:
                if hasattr(tags, "getall"):
                    for u in tags.getall("USLT"):
                        return parse_lrc(str(u.text))
                for k in ("lyrics", "LYRICS", "\xa9lyr", "unsyncedlyrics"):
                    if k in tags:
                        return parse_lrc(_first(tags[k]))
        except Exception:
            pass
    return []


def lyric_index(lines, pos_ms):
    """いま歌っている行の番号(時刻つきの歌詞のみ)。まだ始まっていなければ -1。"""
    if not lines or lines[0][0] is None:
        return -1
    lo, hi, ans = 0, len(lines) - 1, -1
    while lo <= hi:
        mid = (lo + hi) // 2
        if lines[mid][0] <= pos_ms:
            ans, lo = mid, mid + 1
        else:
            hi = mid - 1
    return ans


# ---------- ライブラリ ----------
class Library:
    def __init__(self, path=None):
        self.path = path or os.path.join(data_dir(), "library.json")
        self.tracks = {}      # path -> dict
        self.folders = []
        self.load()

    def clone(self):
        l = Library.__new__(Library)
        l.path, l.tracks, l.folders = self.path, dict(self.tracks), list(self.folders)
        return l

    def load(self):
        try:
            with open(self.path, encoding="utf-8") as fh:
                d = json.load(fh)
            self.tracks = {t["path"]: t for t in d.get("tracks", []) if "path" in t}
            self.folders = list(d.get("folders", []))
        except (OSError, ValueError):
            self.tracks, self.folders = {}, []

    def save(self):
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump({"folders": self.folders, "tracks": list(self.tracks.values())}, fh, ensure_ascii=False)
        os.replace(tmp, self.path)

    def add_folder(self, folder):
        folder = os.path.abspath(folder)
        if folder not in self.folders:
            self.folders.append(folder)

    def remove_folder(self, folder):
        self.folders = [f for f in self.folders if f != folder]
        pre = folder.rstrip("/") + "/"
        for p in [p for p in self.tracks if p.startswith(pre)]:
            del self.tracks[p]

    @staticmethod
    def walk(folder):
        for root, dirs, files in os.walk(folder):
            dirs[:] = sorted(d for d in dirs if not d.startswith("."))
            for n in sorted(files, key=natural_key):
                if is_audio(n) and not n.startswith("."):
                    yield os.path.join(root, n)

    def scan(self, folders=None, progress=None, should_stop=None):
        """新しい曲・変わった曲だけ読み直す。消えた曲は外す。(追加, 更新, 削除) の数を返す。"""
        folders = folders if folders is not None else self.folders
        seen, added, updated = set(), 0, 0
        now = time.time()
        for fo in folders:
            for p in self.walk(fo):
                if should_stop and should_stop():
                    return added, updated, 0
                seen.add(p)
                try:
                    mt = os.path.getmtime(p)
                except OSError:
                    continue
                old = self.tracks.get(p)
                if old and abs(old.get("mtime", 0) - mt) < 1:
                    continue
                t = read_tags(p)
                t["mtime"] = mt
                t["added"] = old.get("added", now) if old else now
                t["plays"] = old.get("plays", 0) if old else 0
                self.tracks[p] = t
                added, updated = (added + 1, updated) if old is None else (added, updated + 1)
                if progress:
                    progress(len(seen), p)
        removed = 0
        for p in list(self.tracks):
            under = any(p.startswith(fo.rstrip("/") + "/") for fo in folders)
            if under and p not in seen:
                del self.tracks[p]
                removed += 1
        return added, updated, removed

    def add_files(self, paths):
        out = []
        now = time.time()
        for p in paths:
            p = os.path.abspath(p)
            if not os.path.isfile(p) or not is_audio(p):
                continue
            if p not in self.tracks:
                t = read_tags(p)
                t["mtime"] = os.path.getmtime(p)
                t["added"] = now
                t["plays"] = 0
                self.tracks[p] = t
            out.append(p)
        return out

    def sorted_tracks(self, tracks=None):
        ts = list(self.tracks.values()) if tracks is None else tracks
        return sorted(ts, key=track_sort_key)

    def albums(self):
        d = {}
        for t in self.tracks.values():
            key = (t.get("album") or "", t.get("albumartist") or t.get("artist") or "")
            d.setdefault(key, []).append(t)
        return d

    def artists(self):
        d = {}
        for t in self.tracks.values():
            d.setdefault(t.get("artist") or "", []).append(t)
        return d


def track_sort_key(t):
    return (natural_key(t.get("albumartist") or t.get("artist")), natural_key(t.get("album")),
            t.get("disc", 0), t.get("track", 0), natural_key(t.get("title")))


# ---------- 再生の順番 ----------
class PlayQueue:
    """再生待ちの曲の列。シャッフルとリピート(なし/全曲/1曲)を扱う。"""

    def __init__(self):
        self.items = []
        self.cur = -1          # items の番号
        self.shuffle = False
        self.repeat = "off"    # off / all / one
        self.order = []        # 再生する順に並べた items の番号
        self.pos = -1          # order の中の位置

    def _rebuild(self, keep_cur=True):
        n = len(self.items)
        self.order = list(range(n))
        if self.shuffle and n:
            random.shuffle(self.order)
            if keep_cur and 0 <= self.cur < n:
                self.order.remove(self.cur)
                self.order.insert(0, self.cur)
        self.pos = self.order.index(self.cur) if 0 <= self.cur < n and self.cur in self.order else -1

    def set(self, items, start=0):
        self.items = list(items)
        self.cur = start if 0 <= start < len(self.items) else -1
        self._rebuild()
        return self.current()

    def current(self):
        return self.items[self.cur] if 0 <= self.cur < len(self.items) else None

    def set_shuffle(self, on):
        self.shuffle = bool(on)
        self._rebuild()

    def _go(self, pos):
        self.pos = pos
        self.cur = self.order[pos]
        return self.items[self.cur]

    def next(self, auto=False):
        """次の曲。auto=True は、曲が終わったときの自動の進み方。なければ None。"""
        if not self.items:
            return None
        if auto and self.repeat == "one" and self.cur >= 0:
            return self.items[self.cur]
        if self.pos + 1 < len(self.order):
            return self._go(self.pos + 1)
        if self.repeat == "all" or (not auto and self.repeat == "one"):
            if self.shuffle:
                self._rebuild(keep_cur=False)
            return self._go(0)
        return None

    def prev(self):
        if not self.items:
            return None
        if self.pos > 0:
            return self._go(self.pos - 1)
        if self.repeat == "all":
            return self._go(len(self.order) - 1)
        return self._go(0)

    def jump(self, index):
        if not 0 <= index < len(self.items):
            return None
        self.cur = index
        self.pos = self.order.index(index)
        return self.items[index]

    def play_next(self, path):
        """いまの曲の、次に再生する。"""
        at = self.cur + 1 if self.cur >= 0 else 0
        self.items.insert(at, path)
        self.order = [i + 1 if i >= at else i for i in self.order]
        self.order.insert(self.pos + 1 if self.pos >= 0 else 0, at)
        if self.cur >= at:
            self.cur += 1
        self.pos = self.order.index(self.cur) if self.cur >= 0 else -1

    def append(self, path):
        self.items.append(path)
        self.order.append(len(self.items) - 1)

    def remove(self, index):
        if not 0 <= index < len(self.items):
            return
        del self.items[index]
        self.order = [i - 1 if i > index else i for i in self.order if i != index]
        if index < self.cur:
            self.cur -= 1
        elif index == self.cur:
            self.cur = -1 if not self.items else min(self.cur, len(self.items) - 1)
        self.pos = self.order.index(self.cur) if self.cur in self.order else -1

    def move(self, src, dst):
        """src の曲を dst の位置へ。いま再生中の曲は、そのまま追いかける。"""
        n = len(self.items)
        if not (0 <= src < n and 0 <= dst < n) or src == dst:
            return
        it = self.items.pop(src)
        self.items.insert(dst, it)
        if self.cur == src:
            self.cur = dst
        elif src < self.cur <= dst:
            self.cur -= 1
        elif dst <= self.cur < src:
            self.cur += 1
        self._rebuild()


# ---------- プレイリスト(m3u) ----------
def write_m3u(path, tracks):
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("#EXTM3U\n")
        for t in tracks:
            fh.write("#EXTINF:%d,%s\n%s\n" % (int(t.get("duration", 0)), (t.get("artist") + " - " if t.get("artist") else "") + t.get("title", ""), t["path"]))


def read_m3u(path):
    base = os.path.dirname(os.path.abspath(path))
    out = []
    for enc in ("utf-8-sig", "cp932"):
        try:
            with open(path, encoding=enc) as fh:
                lines = fh.read().splitlines()
            break
        except UnicodeDecodeError:
            continue
        except OSError:
            return []
    else:
        return []
    for ln in lines:
        ln = ln.strip()
        if not ln or ln.startswith("#"):
            continue
        p = ln if os.path.isabs(ln) else os.path.join(base, ln)
        out.append(os.path.normpath(p))
    return out


def playlists_dir():
    d = os.path.join(data_dir(), "playlists")
    os.makedirs(d, exist_ok=True)
    return d


def list_playlists():
    d = playlists_dir()
    return sorted((os.path.splitext(n)[0] for n in os.listdir(d) if n.lower().endswith(".m3u")), key=natural_key)


def safe_name(name):
    n = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", name).strip(" .")
    return n or "プレイリスト"


# ---------- 設定 ----------
class Settings:
    DEFAULTS = {"volume": 70, "muted": False, "shuffle": False, "repeat": "off", "queue": [], "index": -1, "position": 0,
                "geometry": "", "panel": True, "panel_tab": 0, "view": "songs", "show_remaining": False,
                "rate": 1.0, "sort_col": 0, "sort_desc": False}

    def __init__(self, path=None):
        self.path = path or os.path.join(data_dir(), "settings.json")
        self.d = dict(self.DEFAULTS)
        try:
            with open(self.path, encoding="utf-8") as fh:
                self.d.update(json.load(fh))
        except (OSError, ValueError):
            pass

    def __getitem__(self, k):
        return self.d.get(k, self.DEFAULTS.get(k))

    def __setitem__(self, k, v):
        self.d[k] = v

    def save(self):
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(self.d, fh, ensure_ascii=False)
            os.replace(tmp, self.path)
        except OSError:
            pass


def display(t, key):
    """画面に出す文字(空のときは「不明」)。"""
    v = t.get(key) or ""
    if v:
        return v
    return {"artist": "不明なアーティスト", "album": "不明なアルバム"}.get(key, "")
