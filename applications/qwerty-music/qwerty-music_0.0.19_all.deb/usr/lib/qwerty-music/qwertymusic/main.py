# -*- coding: utf-8 -*-
import json
import os
import sys

from PyQt6.QtCore import QEvent, QObject, Qt
from PyQt6.QtNetwork import QLocalServer, QLocalSocket
from PyQt6.QtWidgets import QApplication, QLineEdit, QPlainTextEdit, QTextEdit, QAbstractSpinBox

from . import APP_ID, APP_NAME, core


class SpaceFilter(QObject):
    """どこにいても、Space で再生 / 一時停止(文字を入力しているときを除く)。"""

    def __init__(self, win):
        super().__init__(win)
        self.win = win

    def eventFilter(self, obj, ev):
        if ev.type() == QEvent.Type.KeyPress and ev.key() == Qt.Key.Key_Space and not ev.modifiers():
            fw = QApplication.focusWidget()
            if isinstance(fw, (QLineEdit, QTextEdit, QPlainTextEdit, QAbstractSpinBox)):
                return False
            from PyQt6.QtWidgets import QPushButton, QToolButton
            if isinstance(fw, (QPushButton, QToolButton)):
                return False
            if QApplication.activeWindow() is self.win:
                self.win.toggle_play()
                return True
        return False


def main(argv=None):
    argv = list(sys.argv if argv is None else argv)
    app = QApplication(argv)
    app.setApplicationName(APP_ID)
    app.setApplicationDisplayName(APP_NAME)
    files = [a for a in argv[1:] if not a.startswith("-")]
    name = "%s-%d" % (APP_ID, os.getuid())

    # すでに動いていれば、そちらに曲を渡して終わる
    sock = QLocalSocket()
    sock.connectToServer(name)
    if sock.waitForConnected(300):
        sock.write(json.dumps([os.path.abspath(f) for f in files]).encode("utf-8"))
        sock.waitForBytesWritten(1000)
        sock.disconnectFromServer()
        return 0

    from .window import MainWindow
    st = core.Settings()
    lib = core.Library()
    w = MainWindow(st, lib, [os.path.abspath(f) for f in files] or None)
    app.installEventFilter(SpaceFilter(w))
    QLocalServer.removeServer(name)
    srv = QLocalServer(w)
    srv.listen(name)

    def on_conn():
        c = srv.nextPendingConnection()

        def read():
            try:
                paths = json.loads(bytes(c.readAll()).decode("utf-8"))
            except ValueError:
                paths = []
            if paths:
                w.open_paths(paths)
            w.showNormal() if w.isMinimized() else None
            w.raise_()
            w.activateWindow()
        c.readyRead.connect(read)
    srv.newConnection.connect(on_conn)
    w.show()
    return app.exec()
