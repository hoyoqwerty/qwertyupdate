# -*- coding: utf-8 -*-
"""アイコンを、プログラムで描く(テーマに左右されず、どの大きさでもくっきり。暗い配色にも合わせられる)。"""
import hashlib

from PyQt6.QtCore import QPointF, QRectF, Qt
from PyQt6.QtGui import QBrush, QColor, QIcon, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap


def _pm(size, ratio, draw):
    pm = QPixmap(int(size * ratio), int(size * ratio))
    pm.setDevicePixelRatio(ratio)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform)
    p.scale(size / 24.0, size / 24.0)
    draw(p)
    p.end()
    return pm


def _poly(pts):
    path = QPainterPath(QPointF(*pts[0]))
    for x, y in pts[1:]:
        path.lineTo(x, y)
    path.closeSubpath()
    return path


def _draw(kind, p, col):
    c = QColor(col)
    fill = QBrush(c)
    stroke = QPen(c, 2.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(fill)
    if kind == "play":
        p.drawPath(_poly([(7, 4.5), (20, 12), (7, 19.5)]))
    elif kind == "pause":
        p.drawRoundedRect(QRectF(6, 4.5, 4.2, 15), 1.2, 1.2)
        p.drawRoundedRect(QRectF(13.8, 4.5, 4.2, 15), 1.2, 1.2)
    elif kind == "next":
        p.drawPath(_poly([(5, 5), (15, 12), (5, 19)]))
        p.drawRoundedRect(QRectF(16.5, 5, 2.8, 14), 1.2, 1.2)
    elif kind == "prev":
        p.drawPath(_poly([(19, 5), (9, 12), (19, 19)]))
        p.drawRoundedRect(QRectF(4.7, 5, 2.8, 14), 1.2, 1.2)
    elif kind in ("shuffle", "repeat", "repeat1"):
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(stroke)
        if kind == "shuffle":
            path = QPainterPath(QPointF(3.5, 7)); path.lineTo(7.5, 7); path.cubicTo(13, 7, 11, 17, 17, 17); path.lineTo(19.5, 17)
            p.drawPath(path)
            path = QPainterPath(QPointF(3.5, 17)); path.lineTo(7.5, 17); path.cubicTo(10, 17, 10.5, 14.5, 11.5, 13)
            p.drawPath(path)
            path = QPainterPath(QPointF(13.5, 11)); path.cubicTo(14.5, 9.5, 15, 7, 17, 7); path.lineTo(19.5, 7)
            p.drawPath(path)
            p.setPen(Qt.PenStyle.NoPen); p.setBrush(fill)
            p.drawPath(_poly([(19, 3.8), (22.5, 7), (19, 10.2)]))
            p.drawPath(_poly([(19, 13.8), (22.5, 17), (19, 20.2)]))
        else:
            p.drawRoundedRect(QRectF(3.5, 6.5, 17, 11), 4, 4)
            p.setPen(Qt.PenStyle.NoPen); p.setBrush(fill)
            p.drawPath(_poly([(12, 3.2), (16, 6.5), (12, 9.8)]))
            p.drawPath(_poly([(12, 14.2), (8, 17.5), (12, 20.8)]))
            if kind == "repeat1":
                p.setPen(QPen(c, 1.8, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                p.drawLine(QPointF(12, 10.2), QPointF(12, 14))
                p.drawLine(QPointF(10.7, 11.2), QPointF(12, 10.2))
    elif kind in ("vol", "vol_low", "mute"):
        p.drawPath(_poly([(3.5, 9.5), (7.5, 9.5), (12, 5.5), (12, 18.5), (7.5, 14.5), (3.5, 14.5)]))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(stroke)
        if kind == "mute":
            p.drawLine(QPointF(16, 9.5), QPointF(21, 14.5)); p.drawLine(QPointF(21, 9.5), QPointF(16, 14.5))
        else:
            p.drawArc(QRectF(8, 8, 8, 8), -50 * 16, 100 * 16)
            if kind == "vol":
                p.drawArc(QRectF(5.5, 5, 14, 14), -55 * 16, 110 * 16)
    elif kind == "queue":
        p.setPen(QPen(c, 2.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        for y in (6, 11, 16):
            p.drawLine(QPointF(4, y), QPointF(15, y))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawPath(_poly([(17, 13.5), (22, 16.5), (17, 19.5)]))
    elif kind == "panel":
        p.setBrush(Qt.BrushStyle.NoBrush); p.setPen(stroke)
        p.drawRoundedRect(QRectF(3.5, 4.5, 17, 15), 2.5, 2.5)
        p.drawLine(QPointF(14.5, 4.5), QPointF(14.5, 19.5))
    elif kind == "mini":
        p.setBrush(Qt.BrushStyle.NoBrush); p.setPen(stroke)
        p.drawRoundedRect(QRectF(3.5, 4.5, 17, 15), 2.5, 2.5)
        p.drawRect(QRectF(11.5, 11.5, 7, 5.5))
    elif kind == "search":
        p.setBrush(Qt.BrushStyle.NoBrush); p.setPen(stroke)
        p.drawEllipse(QRectF(4.5, 4.5, 10, 10)); p.drawLine(QPointF(13, 13), QPointF(19.5, 19.5))
    elif kind == "back":
        p.setBrush(Qt.BrushStyle.NoBrush); p.setPen(stroke)
        path = QPainterPath(QPointF(14.5, 5.5)); path.lineTo(8, 12); path.lineTo(14.5, 18.5); p.drawPath(path)
    elif kind == "songs":
        p.drawEllipse(QRectF(4, 14, 6.5, 5.5)); p.drawEllipse(QRectF(13.5, 12, 6.5, 5.5))
        p.drawRect(QRectF(9, 4.5, 1.8, 12)); p.drawRect(QRectF(18.5, 3, 1.8, 11.5)); p.drawRect(QRectF(9, 4.5, 11.3, 2.6))
    elif kind == "albums":
        p.setBrush(Qt.BrushStyle.NoBrush); p.setPen(stroke)
        p.drawEllipse(QRectF(3.5, 3.5, 17, 17)); p.setBrush(fill); p.setPen(Qt.PenStyle.NoPen); p.drawEllipse(QRectF(9.5, 9.5, 5, 5))
    elif kind == "artists":
        p.drawEllipse(QRectF(8, 3.5, 8, 8)); p.drawPath(_arch(4.5, 20.5, 15, 8))
    elif kind == "recent":
        p.setBrush(Qt.BrushStyle.NoBrush); p.setPen(stroke)
        p.drawEllipse(QRectF(3.5, 3.5, 17, 17)); p.drawLine(QPointF(12, 7.5), QPointF(12, 12)); p.drawLine(QPointF(12, 12), QPointF(15.5, 14))
    elif kind == "top":
        p.drawPath(_poly([(12, 3.5), (14.7, 9), (20.5, 9.7), (16.2, 13.7), (17.4, 19.6), (12, 16.7), (6.6, 19.6), (7.8, 13.7), (3.5, 9.7), (9.3, 9)]))
    elif kind == "list":
        p.setPen(QPen(c, 2.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        for y in (6.5, 12, 17.5):
            p.drawLine(QPointF(8, y), QPointF(20, y)); p.drawPoint(QPointF(4.5, y))
    elif kind == "plus":
        p.setPen(stroke); p.drawLine(QPointF(12, 5.5), QPointF(12, 18.5)); p.drawLine(QPointF(5.5, 12), QPointF(18.5, 12))
    elif kind == "folder":
        p.drawPath(_poly([(3.5, 6), (10, 6), (12, 8.5), (20.5, 8.5), (20.5, 19), (3.5, 19)]))
    elif kind == "note":
        p.drawEllipse(QRectF(5, 14.5, 6.5, 5)); p.drawRect(QRectF(10, 4.5, 1.7, 12.5)); p.drawPath(_poly([(11.7, 4.5), (18.5, 7), (18.5, 10), (11.7, 7.8)]))


def _arch(x, y, w, h):
    path = QPainterPath(QPointF(x, y))
    path.cubicTo(x, y - h * 1.3, x + w, y - h * 1.3, x + w, y)
    path.closeSubpath()
    return path


def make_icon(kind, color, size=24):
    ic = QIcon()
    for ratio in (1, 2):
        ic.addPixmap(_pm(size, ratio, lambda p: _draw(kind, p, color)))
    return ic


def make_pixmap(kind, color, size=24, ratio=2):
    return _pm(size, ratio, lambda p: _draw(kind, p, color))


def _hue(name):
    return int(hashlib.md5((name or "?").encode("utf-8")).hexdigest()[:6], 16) % 360


def placeholder(name, size, ratio=2):
    """絵の無い曲・アルバムの、代わりの絵(名前ごとに色が決まる)。"""
    h = _hue(name)
    return _pm(size, ratio, lambda p: _plain(p, size, h))


def _plain(p, size, h):
    p.resetTransform()
    p.scale(1.0, 1.0)
    g = QLinearGradient(0, 0, size, size)
    g.setColorAt(0, QColor.fromHsl(h, 120, 120))
    g.setColorAt(1, QColor.fromHsl((h + 40) % 360, 130, 80))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QBrush(g))
    p.drawRect(QRectF(0, 0, size, size))
    k = size * 0.5 / 24.0
    p.translate(size * 0.25, size * 0.25)
    p.scale(k, k)
    _draw("note", p, QColor(255, 255, 255, 215))
