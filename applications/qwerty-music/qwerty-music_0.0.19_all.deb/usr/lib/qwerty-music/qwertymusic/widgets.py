# -*- coding: utf-8 -*-
"""画面の部品(つまみ・絵・曲の表・配色)。"""
from PyQt6.QtCore import QAbstractTableModel, QModelIndex, QRectF, QSortFilterProxyModel, Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QPainter, QPainterPath, QPalette, QPixmap
from PyQt6.QtWidgets import QLabel, QSizePolicy, QSlider, QStyle

from . import core
from .icons import placeholder

ACCENT = "#1e6fd9"
UR = Qt.ItemDataRole


def is_dark(pal):
    return pal.color(QPalette.ColorRole.Window).lightness() < 128


def colors(pal):
    """画面の配色(システムの明るい/暗いに合わせる)。"""
    dark = is_dark(pal)
    win = pal.color(QPalette.ColorRole.Window)
    txt = pal.color(QPalette.ColorRole.WindowText)
    c = {
        "dark": dark,
        "bg": win.name(),
        "text": txt.name(),
        "base": pal.color(QPalette.ColorRole.Base).name(),
        "panel": win.darker(108).name() if not dark else win.lighter(115).name(),
        "line": win.darker(122).name() if not dark else win.lighter(145).name(),
        "sub": QColor(txt.red(), txt.green(), txt.blue(), 150).name(QColor.NameFormat.HexArgb),
        "sub2": ("#6b7280" if not dark else "#9aa0a6"),
        "accent": ACCENT if not dark else "#5b9dff",
        "accent_text": "#ffffff",
        "hover": win.darker(106).name() if not dark else win.lighter(125).name(),
        "sel": "#dbe9fb" if not dark else "#27415f",
    }
    return c


def build_qss(c):
    return """
QMainWindow, QDialog { background: %(bg)s; }
QToolTip { background: %(base)s; color: %(text)s; border: 1px solid %(line)s; padding: 4px 6px; }
#sidebar { background: %(panel)s; border: none; border-right: 1px solid %(line)s; outline: 0; padding: 6px 0; }
#sidebar::item { height: 34px; padding-left: 10px; margin: 1px 8px; border-radius: 7px; color: %(text)s; }
#sidebar::item:hover { background: %(hover)s; }
#sidebar::item:selected { background: %(accent)s; color: %(accent_text)s; }
#sidebar::item:disabled { height: 28px; color: %(sub2)s; font-size: 11px; margin-top: 8px; background: transparent; }
#header QLabel#title { font-size: 21px; font-weight: bold; }
#header QLabel#subtitle { color: %(sub2)s; }
QLineEdit#search { background: %(base)s; border: 1px solid %(line)s; border-radius: 15px; padding: 5px 10px 5px 6px; min-height: 20px; }
QLineEdit#search:focus { border: 1px solid %(accent)s; }
QPushButton { background: %(base)s; border: 1px solid %(line)s; border-radius: 6px; padding: 6px 14px; color: %(text)s; }
QPushButton:hover { background: %(hover)s; }
QPushButton:pressed { background: %(line)s; }
QPushButton:disabled { color: %(sub2)s; }
QPushButton#primary { background: %(accent)s; color: %(accent_text)s; border: 1px solid %(accent)s; font-weight: bold; padding: 6px 18px; }
QPushButton#primary:hover { background: %(accent)s; }
QTableView { color: %(text)s; background: %(base)s; alternate-background-color: %(base)s; border: none; gridline-color: transparent; outline: 0; selection-background-color: %(sel)s; selection-color: %(text)s; }
QTableView::item { padding: 0 8px; border: none; }
QTableView::item:hover { background: %(hover)s; }
QTableView::item:selected { background: %(sel)s; color: %(text)s; }
QHeaderView::section { background: %(base)s; color: %(sub2)s; border: none; border-bottom: 1px solid %(line)s; padding: 6px 8px; font-weight: normal; }
QHeaderView::section:hover { color: %(text)s; }
QListWidget { color: %(text)s; background: %(base)s; border: none; outline: 0; }
QListWidget#albums::item { border-radius: 8px; padding: 6px; color: %(text)s; }
QListWidget#albums::item:hover { background: %(hover)s; }
QListWidget#albums::item:selected { background: %(sel)s; color: %(text)s; }
QListWidget#artists::item, QListWidget#queue::item, QListWidget#lyrics::item { padding: 7px 10px; border-radius: 6px; }
QListWidget#artists::item:hover, QListWidget#queue::item:hover { background: %(hover)s; }
QListWidget#artists::item:selected, QListWidget#queue::item:selected { background: %(sel)s; color: %(text)s; }
QListWidget#lyrics::item { padding: 6px 12px; }
QListWidget#lyrics::item:hover, QListWidget#lyrics::item:selected { background: transparent; }
#rightpanel { background: %(base)s; border-left: 1px solid %(line)s; }
#rightpanel QLabel#ptitle { font-size: 17px; font-weight: bold; }
#rightpanel QLabel#psub { color: %(sub2)s; }
QTabBar { qproperty-drawBase: 0; background: transparent; }
QTabBar::tab { background: transparent; padding: 8px 14px; border: none; border-bottom: 2px solid transparent; color: %(sub2)s; }
QTabBar::tab:selected { color: %(text)s; border-bottom: 2px solid %(accent)s; }
QTabBar::tab:hover { color: %(text)s; }
QTabWidget::pane { border: none; border-top: 1px solid %(line)s; }
#bar { background: %(panel)s; border-top: 1px solid %(line)s; }
#bar QLabel#now_title { font-weight: bold; font-size: 14px; }
#bar QLabel#now_sub { color: %(sub2)s; }
#bar QLabel#time { color: %(sub2)s; }
QToolButton { background: transparent; border: none; border-radius: 17px; padding: 0; }
QToolButton:hover { background: %(hover)s; }
QToolButton:pressed { background: %(line)s; }
QToolButton:checked { background: %(sel)s; }
QToolButton#play { background: %(accent)s; border-radius: 23px; }
QToolButton#play:hover { background: %(accent)s; }
QToolButton#play:pressed { background: %(accent)s; }
QSlider::groove:horizontal { height: 4px; background: %(line)s; border-radius: 2px; }
QSlider::sub-page:horizontal { background: %(accent)s; border-radius: 2px; }
QSlider::handle:horizontal { width: 0px; margin: -5px 0; background: %(accent)s; border-radius: 7px; }
QSlider:hover::handle:horizontal, QSlider::handle:horizontal:pressed { width: 14px; }
QScrollBar:vertical { width: 12px; background: transparent; margin: 0; }
QScrollBar::handle:vertical { background: %(line)s; border-radius: 4px; min-height: 30px; margin: 2px; }
QScrollBar::handle:vertical:hover { background: %(sub2)s; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical, QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { height: 0; background: transparent; }
QScrollBar:horizontal { height: 12px; background: transparent; }
QScrollBar::handle:horizontal { background: %(line)s; border-radius: 4px; min-width: 30px; margin: 2px; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal, QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal { width: 0; background: transparent; }
QStatusBar { background: %(panel)s; color: %(sub2)s; border-top: 1px solid %(line)s; }
QStatusBar::item { border: none; }
QMenu { background: %(base)s; border: 1px solid %(line)s; padding: 4px; }
QMenu::item { padding: 6px 26px 6px 14px; border-radius: 4px; }
QMenu::item:selected { background: %(accent)s; color: %(accent_text)s; }
QMenu::separator { height: 1px; background: %(line)s; margin: 4px 8px; }
QMenuBar { background: %(bg)s; }
QMenuBar::item { padding: 5px 10px; background: transparent; }
QMenuBar::item:selected { background: %(hover)s; border-radius: 4px; }
#empty QLabel#etitle { font-size: 20px; font-weight: bold; }
#empty QLabel#etext { color: %(sub2)s; }
""" % c


class SeekSlider(QSlider):
    """クリックした場所へ、すぐ移れるつまみ。"""
    pressedAt = pyqtSignal(int)

    def __init__(self, *a, **k):
        super().__init__(Qt.Orientation.Horizontal, *a, **k)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedHeight(20)
        self.setSingleStep(5000)
        self.setPageStep(10000)

    def _val(self, x):
        return QStyle.sliderValueFromPosition(self.minimum(), self.maximum(), int(x), max(1, self.width()))

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton and self.maximum() > 0:
            self.setSliderDown(True)
            self.setValue(self._val(e.position().x()))
            self.sliderMoved.emit(self.value())
            e.accept()
        else:
            super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self.isSliderDown():
            self.setValue(self._val(e.position().x()))
            self.sliderMoved.emit(self.value())
            e.accept()
        else:
            super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        if self.isSliderDown():
            self.setSliderDown(False)
            e.accept()
        else:
            super().mouseReleaseEvent(e)

    def wheelEvent(self, e):
        e.ignore()


class CoverLabel(QLabel):
    """四角い絵(角を丸くして、はみ出さずに表示)。"""

    def __init__(self, size, radius=8, parent=None):
        super().__init__(parent)
        self._pm = None
        self._radius = radius
        self._name = ""
        self.setFixedSize(size, size)
        self.set_cover(None, "")

    def set_cover(self, pixmap, name):
        self._name = name
        self._pm = pixmap
        self.update()

    def resizeTo(self, size):
        self.setFixedSize(size, size)
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform)
        path = QPainterPath()
        path.addRoundedRect(QRectF(self.rect()), self._radius, self._radius)
        p.setClipPath(path)
        s = self.width()
        dpr = self.devicePixelRatioF()
        if self._pm is None or self._pm.isNull():
            p.drawPixmap(0, 0, placeholder(self._name, s, dpr))
        else:
            side = min(self._pm.width(), self._pm.height())
            x = (self._pm.width() - side) // 2
            y = (self._pm.height() - side) // 2
            p.drawPixmap(QRectF(0, 0, s, s), self._pm, QRectF(x, y, side, side))


class ElideLabel(QLabel):
    """はみ出す文字を「…」で省く(見切れ防止)。全文は、マウスを乗せると出る。"""

    def __init__(self, text="", parent=None):
        super().__init__(parent)
        self._full = ""
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.setMinimumWidth(10)
        self.setText(text)

    def setText(self, t):
        self._full = t or ""
        self.setToolTip(self._full)
        self._apply()

    def text(self):
        return self._full

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._apply()

    def _apply(self):
        fm = self.fontMetrics()
        QLabel.setText(self, fm.elidedText(self._full, Qt.TextElideMode.ElideRight, max(10, self.width())))


COLS = ["", "タイトル", "アーティスト", "アルバム", "時間"]
SORT = UR.UserRole + 1


class TrackModel(QAbstractTableModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.tracks = []
        self.playing = ""
        self.accent = QColor(ACCENT)
        self.playing_active = False

    def set_tracks(self, tracks):
        self.beginResetModel()
        self.tracks = list(tracks)
        self.endResetModel()

    def set_playing(self, path, active):
        self.playing, self.playing_active = path, active
        if self.tracks:
            self.dataChanged.emit(self.index(0, 0), self.index(len(self.tracks) - 1, len(COLS) - 1))

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.tracks)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(COLS)

    def headerData(self, s, o, role=UR.DisplayRole):
        if o == Qt.Orientation.Horizontal:
            if role == UR.DisplayRole:
                return COLS[s]
            if role == UR.TextAlignmentRole:
                return int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter) if s == 4 else int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        return None

    def data(self, idx, role=UR.DisplayRole):
        if not idx.isValid():
            return None
        t = self.tracks[idx.row()]
        c = idx.column()
        if role == UR.DisplayRole:
            if c == 0:
                return ("▶" if self.playing_active else "❚❚") if t["path"] == self.playing else ""
            if c == 1:
                return t.get("title", "")
            if c == 2:
                return core.display(t, "artist")
            if c == 3:
                return core.display(t, "album")
            if c == 4:
                return core.fmt_time(t.get("duration", 0))
        elif role == UR.UserRole:
            return t["path"]
        elif role == SORT:
            if c == 0:
                return 0
            if c == 4:
                return float(t.get("duration", 0))
            return core.natural_key(t.get(("title", "artist", "album")[c - 1], "") or "")
        elif role == UR.TextAlignmentRole:
            return int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter) if c == 4 else int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        elif role == UR.ForegroundRole:
            if t["path"] == self.playing:
                return self.accent
            if c in (2, 3, 4):
                return None
        elif role == UR.FontRole:
            if t["path"] == self.playing:
                f = QFont()
                f.setBold(True)
                return f
        elif role == UR.ToolTipRole:
            return "%s\n%s — %s" % (t.get("title", ""), core.display(t, "artist"), core.display(t, "album"))
        return None


class Proxy(QSortFilterProxyModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.needle = ""
        self.setSortRole(SORT)

    def set_needle(self, s):
        self.needle = (s or "").strip().lower()
        self.invalidateFilter()

    def filterAcceptsRow(self, row, parent):
        if not self.needle:
            return True
        t = self.sourceModel().tracks[row]
        hay = " ".join((t.get("title", ""), t.get("artist", ""), t.get("album", ""), t.get("genre", ""))).lower()
        return all(w in hay for w in self.needle.split())

    def lessThan(self, a, b):
        x, y = a.data(SORT), b.data(SORT)
        try:
            return x < y
        except TypeError:
            return str(x) < str(y)
