APP_NAME = "ミュージックプレーヤー"
APP_ID = "qwerty-music"
