# -*- coding: utf-8 -*-
"""qwerty-music の本体の画面。"""
import base64
import json
import os
import subprocess

from PyQt6.QtCore import QEvent, QPoint, QSize, Qt, QThread, QTimer, QUrl, pyqtSignal
from PyQt6.QtGui import QAction, QActionGroup, QColor, QFont, QIcon, QKeySequence, QPixmap
from PyQt6.QtMultimedia import QAudio, QAudioOutput, QMediaDevices, QMediaPlayer
from PyQt6.QtWidgets import (QApplication, QDialog, QFileDialog, QFormLayout, QFrame, QHBoxLayout, QInputDialog, QLabel,
                             QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMenu, QMessageBox, QPushButton,
                             QStackedWidget, QTabWidget, QTableView, QToolButton, QVBoxLayout, QWidget, QAbstractItemView,
                             QHeaderView, QSizePolicy, QTextEdit)

from . import APP_NAME, core
from .icons import make_icon, make_pixmap, placeholder
from .widgets import (ACCENT, COLS, CoverLabel, ElideLabel, Proxy, SeekSlider, TrackModel, build_qss, colors, UR)

SB = Qt.ItemDataRole.UserRole


class NullAudio:
    """音を出す機器が無いとき(または試験のとき)の、身代わり。"""
    def __init__(self):
        self._v, self._m = 1.0, False

    def setVolume(self, v):
        self._v = v

    def volume(self):
        return self._v

    def setMuted(self, m):
        self._m = bool(m)

    def isMuted(self):
        return self._m


class ScanThread(QThread):
    progress = pyqtSignal(int, str)
    finished_scan = pyqtSignal(object, int, int, int)

    def __init__(self, lib, parent=None):
        super().__init__(parent)
        self.lib = lib
        self.stop = False

    def run(self):
        a, u, r = self.lib.scan(progress=lambda n, p: self.progress.emit(n, p) if n % 10 == 0 else None,
                                should_stop=lambda: self.stop)
        self.finished_scan.emit(self.lib, a, u, r)


class MainWindow(QMainWindow):
    def __init__(self, settings, library, files=None):
        super().__init__()
        self.st = settings
        self.lib = library
        self.queue = core.PlayQueue()
        self.cur = None                  # いまの曲(dict)
        self.view = ("songs", None)
        self.cover_cache = {}
        self.lyrics = []
        self.lyric_row = -1
        self.pending_seek = 0
        self.counted = False
        self.errors = 0
        self.scan_thread = None
        self.mini = False
        self.normal_geo = None
        self.sleep_left = 0              # 秒(0 なら、なし)
        self.sleep_end_of_track = False
        self.fade = None
        self.thumb_todo = []
        self.setWindowTitle(APP_NAME)
        self.setAcceptDrops(True)
        self.resize(1180, 720)
        self.setMinimumSize(980, 580)

        self.player = QMediaPlayer(self)
        self.no_audio = bool(os.environ.get("QWERTY_MUSIC_NOAUDIO")) or not QMediaDevices.audioOutputs()
        if self.no_audio:
            self.audio = NullAudio()
        else:
            self.audio = QAudioOutput(self)
            self.player.setAudioOutput(self.audio)
        self.player.positionChanged.connect(self.on_position)
        self.player.durationChanged.connect(self.on_duration)
        self.player.mediaStatusChanged.connect(self.on_status)
        self.player.playbackStateChanged.connect(self.on_state)
        self.player.errorOccurred.connect(self.on_error)

        self.build_ui()
        self.build_menus()
        self.apply_theme()
        self.refresh_sidebar()
        self.restore()
        if files:
            QTimer.singleShot(0, lambda: self.open_paths(files))
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(1000)
        if self.no_audio and not os.environ.get("QWERTY_MUSIC_NOAUDIO"):
            self.statusBar().showMessage("音を出す機器が見つかりません。(仮想マシンの設定で、サウンドカードを確認してください)", 20000)
        if self.lib.folders:
            QTimer.singleShot(300, self.rescan)

    # ------------------------------------------------------------------ 画面を作る
    def build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        body = QHBoxLayout()
        body.setSpacing(0)
        root.addLayout(body, 1)

        # 左: 見出しの一覧
        self.sidebar = QListWidget()
        self.sidebar.setObjectName("sidebar")
        self.sidebar.setFixedWidth(190)
        self.sidebar.setIconSize(QSize(18, 18))
        self.sidebar.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.sidebar.customContextMenuRequested.connect(self.sidebar_menu)
        self.sidebar.itemClicked.connect(self.on_sidebar)
        body.addWidget(self.sidebar)

        # 中央: 見出し + 内容
        mid = QWidget()
        ml = QVBoxLayout(mid)
        ml.setContentsMargins(0, 0, 0, 0)
        ml.setSpacing(0)
        self.header = QFrame()
        self.header.setObjectName("header")
        hv = QVBoxLayout(self.header)
        hv.setContentsMargins(22, 16, 22, 10)
        hv.setSpacing(10)
        hl = QHBoxLayout()
        hl.setSpacing(8)
        self.back_btn = QToolButton()
        self.back_btn.setFixedSize(34, 34)
        self.back_btn.setToolTip("もどる")
        self.back_btn.clicked.connect(self.go_back)
        hl.addWidget(self.back_btn)
        tbox = QVBoxLayout()
        tbox.setSpacing(0)
        self.title_lbl = ElideLabel("曲")
        self.title_lbl.setObjectName("title")
        self.sub_lbl = ElideLabel("")
        self.sub_lbl.setObjectName("subtitle")
        tbox.addWidget(self.title_lbl)
        tbox.addWidget(self.sub_lbl)
        hl.addLayout(tbox, 1)
        hv.addLayout(hl)
        hl2 = QHBoxLayout()
        hl2.setSpacing(8)
        self.play_all_btn = QPushButton("すべて再生")
        self.play_all_btn.setObjectName("primary")
        self.play_all_btn.clicked.connect(lambda: self.play_visible(shuffle=False))
        self.shuffle_all_btn = QPushButton("シャッフル再生")
        self.shuffle_all_btn.clicked.connect(lambda: self.play_visible(shuffle=True))
        hl2.addWidget(self.play_all_btn)
        hl2.addWidget(self.shuffle_all_btn)
        hl2.addStretch(1)
        self.search = QLineEdit()
        self.search.setObjectName("search")
        self.search.setPlaceholderText("曲・アーティスト・アルバムを検索")
        self.search.setClearButtonEnabled(True)
        self.search.setMinimumWidth(200)
        self.search.setMaximumWidth(300)
        self.search.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.search.textChanged.connect(self.on_search)
        hl2.addWidget(self.search, 1)
        hv.addLayout(hl2)
        ml.addWidget(self.header)

        self.stack = QStackedWidget()
        ml.addWidget(self.stack, 1)
        body.addWidget(mid, 1)

        # 0: 曲の表
        self.model = TrackModel(self)
        self.proxy = Proxy(self)
        self.proxy.setSourceModel(self.model)
        self.table = QTableView()
        self.table.setModel(self.proxy)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setShowGrid(False)
        self.table.setAlternatingRowColors(False)
        self.table.verticalHeader().hide()
        self.table.verticalHeader().setDefaultSectionSize(38)
        self.table.setWordWrap(False)
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.table.setTextElideMode(Qt.TextElideMode.ElideRight)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.table_menu)
        self.table.doubleClicked.connect(self.on_table_activate)
        self.table.setSortingEnabled(True)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        hh.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(2, QHeaderView.ResizeMode.Interactive)
        hh.setSectionResizeMode(3, QHeaderView.ResizeMode.Interactive)
        hh.setSectionResizeMode(4, QHeaderView.ResizeMode.Fixed)
        hh.setStretchLastSection(False)
        hh.setHighlightSections(False)
        hh.setSortIndicatorShown(True)
        self.table.setColumnWidth(0, 34)
        self.table.setColumnWidth(2, 200)
        self.table.setColumnWidth(3, 220)
        self.table.setColumnWidth(4, 80)
        self.table.sortByColumn(-1, Qt.SortOrder.AscendingOrder)
        self.table.viewport().installEventFilter(self)
        self.stack.addWidget(self.table)

        # 1: アルバムの並び
        self.albums = QListWidget()
        self.albums.setObjectName("albums")
        self.albums.setViewMode(QListWidget.ViewMode.IconMode)
        self.albums.setIconSize(QSize(168, 168))
        self.albums.setGridSize(QSize(196, 236))
        self.albums.setResizeMode(QListWidget.ResizeMode.Adjust)
        self.albums.setMovement(QListWidget.Movement.Static)
        self.albums.setWordWrap(True)
        self.albums.setUniformItemSizes(True)
        self.albums.setSpacing(4)
        self.albums.setTextElideMode(Qt.TextElideMode.ElideRight)
        self.albums.setContentsMargins(14, 8, 14, 8)
        self.albums.itemActivated.connect(self.on_album)
        self.albums.itemClicked.connect(self.on_album)
        self.stack.addWidget(self.albums)

        # 2: アーティストの一覧
        self.artists = QListWidget()
        self.artists.setObjectName("artists")
        self.artists.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.artists.itemClicked.connect(self.on_artist)
        self.artists.itemActivated.connect(self.on_artist)
        self.stack.addWidget(self.artists)

        # 3: 曲が無いとき
        self.empty = QWidget()
        self.empty.setObjectName("empty")
        el = QVBoxLayout(self.empty)
        el.setAlignment(Qt.AlignmentFlag.AlignCenter)
        el.setSpacing(10)
        self.empty_icon = QLabel()
        self.empty_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty_title = QLabel("まだ曲がありません")
        self.empty_title.setObjectName("etitle")
        self.empty_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty_text = QLabel("音楽の入っているフォルダーを追加すると、ここに曲が並びます。\n曲のファイルを、この画面へドラッグしても追加できます。")
        self.empty_text.setObjectName("etext")
        self.empty_text.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty_text.setWordWrap(True)
        er = QHBoxLayout()
        er.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty_music_btn = QPushButton("ミュージックフォルダーを追加")
        self.empty_music_btn.setObjectName("primary")
        self.empty_music_btn.clicked.connect(self.add_music_dir)
        b2 = QPushButton("フォルダーを選んで追加…")
        b2.clicked.connect(self.add_folder_dialog)
        b3 = QPushButton("ファイルを開く…")
        b3.clicked.connect(self.add_files_dialog)
        for b in (self.empty_music_btn, b2, b3):
            er.addWidget(b)
        el.addWidget(self.empty_icon)
        el.addWidget(self.empty_title)
        el.addWidget(self.empty_text)
        el.addLayout(er)
        self.stack.addWidget(self.empty)

        # 右: 再生中パネル
        self.panel = QFrame()
        self.panel.setObjectName("rightpanel")
        self.panel.setFixedWidth(300)
        pl = QVBoxLayout(self.panel)
        pl.setContentsMargins(18, 18, 18, 0)
        pl.setSpacing(6)
        self.big_cover = CoverLabel(264, 10)
        pl.addWidget(self.big_cover, 0, Qt.AlignmentFlag.AlignHCenter)
        pl.addSpacing(8)
        self.p_title = QLabel("再生していません")
        self.p_title.setObjectName("ptitle")
        self.p_title.setWordWrap(True)
        self.p_artist = ElideLabel("")
        self.p_artist.setObjectName("psub")
        self.p_album = ElideLabel("")
        self.p_album.setObjectName("psub")
        pl.addWidget(self.p_title)
        pl.addWidget(self.p_artist)
        pl.addWidget(self.p_album)
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.lyrics_list = QListWidget()
        self.lyrics_list.setObjectName("lyrics")
        self.lyrics_list.setWordWrap(True)
        self.lyrics_list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.lyrics_list.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.lyrics_list.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.lyrics_list.itemClicked.connect(self.on_lyric_click)
        self.tabs.addTab(self.lyrics_list, "歌詞")
        qw = QWidget()
        ql = QVBoxLayout(qw)
        ql.setContentsMargins(0, 6, 0, 0)
        qh = QHBoxLayout()
        self.queue_lbl = QLabel("次に再生")
        self.queue_clear = QPushButton("クリア")
        self.queue_clear.clicked.connect(self.clear_queue)
        qh.addWidget(self.queue_lbl, 1)
        qh.addWidget(self.queue_clear)
        ql.addLayout(qh)
        self.queue_list = QListWidget()
        self.queue_list.setObjectName("queue")
        self.queue_list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.queue_list.setTextElideMode(Qt.TextElideMode.ElideRight)
        self.queue_list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.queue_list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.queue_list.itemDoubleClicked.connect(lambda it: self.jump_to(self.queue_list.row(it)))
        self.queue_list.model().rowsMoved.connect(self.on_queue_moved)
        self.queue_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.queue_list.customContextMenuRequested.connect(self.queue_menu)
        ql.addWidget(self.queue_list, 1)
        self.tabs.addTab(qw, "再生待ち")
        pl.addWidget(self.tabs, 1)
        body.addWidget(self.panel)

        # 下: 再生バー
        self.bar = QFrame()
        self.bar.setObjectName("bar")
        self.bar.setFixedHeight(92)
        bl = QHBoxLayout(self.bar)
        bl.setContentsMargins(16, 8, 16, 8)
        bl.setSpacing(14)
        left = QHBoxLayout()
        left.setSpacing(12)
        self.mini_cover = CoverLabel(64, 7)
        left.addWidget(self.mini_cover)
        ln = QVBoxLayout()
        ln.setSpacing(2)
        ln.addStretch(1)
        self.now_title = ElideLabel("再生していません")
        self.now_title.setObjectName("now_title")
        self.now_sub = ElideLabel("")
        self.now_sub.setObjectName("now_sub")
        ln.addWidget(self.now_title)
        ln.addWidget(self.now_sub)
        ln.addStretch(1)
        left.addLayout(ln, 1)
        lw = QWidget()
        lw.setLayout(left)
        lw.setFixedWidth(280)
        bl.addWidget(lw)

        center = QVBoxLayout()
        center.setSpacing(4)
        tr = QHBoxLayout()
        tr.setSpacing(10)
        tr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.btn_shuffle = self.tbtn("シャッフル (S)", 34, checkable=True)
        self.btn_prev = self.tbtn("前の曲 (Ctrl+←)", 34)
        self.btn_play = self.tbtn("再生 / 一時停止 (Space)", 46)
        self.btn_play.setObjectName("play")
        self.btn_next = self.tbtn("次の曲 (Ctrl+→)", 34)
        self.btn_repeat = self.tbtn("リピート (R)", 34, checkable=True)
        for b in (self.btn_shuffle, self.btn_prev, self.btn_play, self.btn_next, self.btn_repeat):
            tr.addWidget(b)
        center.addLayout(tr)
        sr = QHBoxLayout()
        sr.setSpacing(8)
        self.t_left = QLabel("0:00")
        self.t_left.setObjectName("time")
        self.t_left.setFixedWidth(56)
        self.t_left.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.t_right = QLabel("0:00")
        self.t_right.setObjectName("time")
        self.t_right.setFixedWidth(56)
        self.t_right.setCursor(Qt.CursorShape.PointingHandCursor)
        self.t_right.setToolTip("クリックで、「全体の長さ」と「残り時間」を切り替えます")
        self.t_right.installEventFilter(self)
        self.seek = SeekSlider()
        self.seek.setRange(0, 0)
        self.seek.sliderMoved.connect(self.on_seek_moved)
        self.seek.sliderReleased.connect(self.on_seek_released)
        sr.addWidget(self.t_left)
        sr.addWidget(self.seek, 1)
        sr.addWidget(self.t_right)
        center.addLayout(sr)
        cw = QWidget()
        cw.setLayout(center)
        bl.addWidget(cw, 1)

        right = QHBoxLayout()
        right.setSpacing(6)
        self.sleep_lbl = QLabel("")
        self.sleep_lbl.setObjectName("time")
        self.btn_mute = self.tbtn("ミュート (M)", 34)
        self.vol = SeekSlider()
        self.vol.setRange(0, 100)
        self.vol.setFixedWidth(96)
        self.vol.setSingleStep(5)
        self.vol.setPageStep(10)
        self.vol.valueChanged.connect(self.on_volume)
        self.btn_panel = self.tbtn("再生中パネルの表示 / 非表示", 34, checkable=True)
        self.btn_mini = self.tbtn("ミニプレーヤー (F2)", 34)
        right.addWidget(self.sleep_lbl)
        right.addWidget(self.btn_mute)
        right.addWidget(self.vol)
        right.addSpacing(6)
        right.addWidget(self.btn_panel)
        right.addWidget(self.btn_mini)
        rw = QWidget()
        rw.setLayout(right)
        rw.setFixedWidth(300)
        bl.addWidget(rw)
        root.addWidget(self.bar)

        self.btn_shuffle.clicked.connect(self.set_shuffle)
        self.btn_prev.clicked.connect(self.prev_track)
        self.btn_play.clicked.connect(self.toggle_play)
        self.btn_next.clicked.connect(self.next_track)
        self.btn_repeat.clicked.connect(self.cycle_repeat)
        self.btn_mute.clicked.connect(self.toggle_mute)
        self.btn_panel.clicked.connect(self.toggle_panel)
        self.btn_mini.clicked.connect(self.toggle_mini)

        self.scan_lbl = QLabel("")
        self.statusBar().addPermanentWidget(self.scan_lbl)
        self.statusBar().setSizeGripEnabled(False)

    def tbtn(self, tip, size, checkable=False):
        b = QToolButton()
        b.setToolTip(tip)
        b.setFixedSize(size, size)
        b.setCheckable(checkable)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.setFocusPolicy(Qt.FocusPolicy.TabFocus)
        return b

    # ------------------------------------------------------------------ メニュー
    def build_menus(self):
        mb = self.menuBar()
        def act(menu, text, slot, shortcut=None, checkable=False):
            a = QAction(text, self)
            a.setCheckable(checkable)
            if shortcut:
                a.setShortcut(QKeySequence(shortcut))
            a.triggered.connect(slot)
            menu.addAction(a)
            return a
        m = mb.addMenu("ファイル(&F)")
        act(m, "ファイルを開く…", self.add_files_dialog, "Ctrl+O")
        act(m, "フォルダーを追加…", self.add_folder_dialog, "Ctrl+Shift+O")
        act(m, "プレイリストを開く…", self.open_playlist_file)
        m.addSeparator()
        act(m, "ライブラリを読み込み直す", self.rescan, "F5")
        act(m, "ライブラリのフォルダーを管理…", self.manage_folders)
        m.addSeparator()
        act(m, "終了", self.close, "Ctrl+Q")

        m = mb.addMenu("再生(&P)")
        self.act_play = act(m, "再生 / 一時停止", self.toggle_play)
        act(m, "前の曲", self.prev_track, "Ctrl+Left")
        act(m, "次の曲", self.next_track, "Ctrl+Right")
        act(m, "5 秒戻る", lambda: self.seek_by(-5000), "Alt+Left")
        act(m, "5 秒進む", lambda: self.seek_by(5000), "Alt+Right")
        m.addSeparator()
        self.act_shuffle = act(m, "シャッフル", lambda: self.set_shuffle(not self.queue.shuffle), "S", True)
        self.act_repeat = act(m, "リピートを切り替える(なし → 全曲 → 1曲)", self.cycle_repeat, "R")
        m.addSeparator()
        act(m, "音量を上げる", lambda: self.vol.setValue(self.vol.value() + 5), "Ctrl+Up")
        act(m, "音量を下げる", lambda: self.vol.setValue(self.vol.value() - 5), "Ctrl+Down")
        act(m, "ミュート", self.toggle_mute, "M")
        rate = m.addMenu("再生の速さ")
        grp = QActionGroup(self)
        self.rate_acts = {}
        for r in (0.75, 1.0, 1.25, 1.5, 2.0):
            a = QAction("%s 倍" % ("%g" % r) + ("(ふつう)" if r == 1.0 else ""), self)
            a.setCheckable(True)
            a.setActionGroup(grp)
            a.triggered.connect(lambda _, r=r: self.set_rate(r))
            rate.addAction(a)
            self.rate_acts[r] = a
        sl = m.addMenu("スリープタイマー")
        grp2 = QActionGroup(self)
        self.sleep_acts = []
        for label, mins in (("オフ", 0), ("15 分", 15), ("30 分", 30), ("60 分", 60), ("90 分", 90), ("この曲の終わりに止める", -1)):
            a = QAction(label, self)
            a.setCheckable(True)
            a.setActionGroup(grp2)
            a.triggered.connect(lambda _, mins=mins: self.set_sleep(mins))
            sl.addAction(a)
            self.sleep_acts.append(a)
        self.sleep_acts[0].setChecked(True)

        m = mb.addMenu("表示(&V)")
        for text, key, view in (("曲", "Ctrl+1", ("songs", None)), ("アルバム", "Ctrl+2", ("albums", None)), ("アーティスト", "Ctrl+3", ("artists", None))):
            act(m, text, lambda _=False, v=view: self.show_view(*v), key)
        act(m, "検索", lambda: (self.search.setFocus(), self.search.selectAll()), "Ctrl+F")
        m.addSeparator()
        self.act_panel = act(m, "再生中パネル", self.toggle_panel, "F3", True)
        act(m, "歌詞を見る", lambda: self.show_panel_tab(0), "Ctrl+L")
        act(m, "再生待ちを見る", lambda: self.show_panel_tab(1), "Ctrl+J")
        act(m, "ミニプレーヤー", self.toggle_mini, "F2")
        self.act_top = act(m, "常に手前に表示", self.toggle_top, None, True)

        m = mb.addMenu("ヘルプ(&H)")
        act(m, "キーボードの操作一覧", self.show_keys, "F1")
        act(m, "%s について" % APP_NAME, self.show_about)

    # ------------------------------------------------------------------ 見た目
    def apply_theme(self):
        self.c = colors(QApplication.palette())
        QApplication.instance().setStyleSheet(build_qss(self.c))
        col = self.c["text"]
        acc = self.c["accent"]
        self.ic = lambda k, color=col, s=22: make_icon(k, color, s)
        self.btn_shuffle.setIcon(self.ic("shuffle", col, 22)); self.btn_shuffle.setIconSize(QSize(22, 22))
        self.btn_prev.setIcon(self.ic("prev", col, 22)); self.btn_prev.setIconSize(QSize(22, 22))
        self.btn_next.setIcon(self.ic("next", col, 22)); self.btn_next.setIconSize(QSize(22, 22))
        self.btn_play.setIconSize(QSize(26, 26))
        self.btn_repeat.setIconSize(QSize(22, 22))
        self.btn_mute.setIconSize(QSize(20, 20))
        self.btn_panel.setIcon(self.ic("panel", col, 22)); self.btn_panel.setIconSize(QSize(20, 20))
        self.btn_mini.setIcon(self.ic("mini", col, 22)); self.btn_mini.setIconSize(QSize(20, 20))
        self.back_btn.setIcon(self.ic("back", col, 22)); self.back_btn.setIconSize(QSize(20, 20))
        self.model.accent = QColor(acc)
        self.update_play_icon()
        self.update_repeat_icon()
        self.update_mute_icon()
        self.empty_icon.setPixmap(make_pixmap("note", self.c["sub2"], 84))
        self.search_action_icon()
        self.refresh_sidebar_icons()

    def search_action_icon(self):
        if not hasattr(self, "_search_act"):
            self._search_act = self.search.addAction(self.ic("search", self.c["sub2"], 16), QLineEdit.ActionPosition.LeadingPosition)
        else:
            self._search_act.setIcon(self.ic("search", self.c["sub2"], 16))

    def update_play_icon(self):
        playing = self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState
        self.btn_play.setIcon(make_icon("pause" if playing else "play", "#ffffff", 26))

    def update_repeat_icon(self):
        r = self.queue.repeat
        self.btn_repeat.setIcon(self.ic("repeat1" if r == "one" else "repeat", self.c["accent"] if r != "off" else self.c["text"], 22))
        self.btn_repeat.setChecked(r != "off")
        self.btn_repeat.setToolTip("リピート: " + {"off": "なし", "all": "全曲", "one": "1曲"}[r] + " (R)")

    def update_mute_icon(self):
        muted = self.audio.isMuted() or self.vol.value() == 0
        k = "mute" if muted else ("vol_low" if self.vol.value() < 40 else "vol")
        self.btn_mute.setIcon(self.ic(k, self.c["text"], 22))

    # ------------------------------------------------------------------ サイドバー
    SIDE = (("songs", "曲", "songs"), ("albums", "アルバム", "albums"), ("artists", "アーティスト", "artists"),
            ("recent", "最近追加した曲", "recent"), ("top", "よく聞く曲", "top"))

    def refresh_sidebar(self):
        keep = self.view
        self.sidebar.clear()
        h = QListWidgetItem("ライブラリ")
        h.setFlags(Qt.ItemFlag.NoItemFlags)
        self.sidebar.addItem(h)
        for kind, text, icon in self.SIDE:
            it = QListWidgetItem(text)
            it.setData(SB, (kind, None))
            it.setData(SB + 1, icon)
            self.sidebar.addItem(it)
        h = QListWidgetItem("プレイリスト")
        h.setFlags(Qt.ItemFlag.NoItemFlags)
        self.sidebar.addItem(h)
        for n in core.list_playlists():
            it = QListWidgetItem(n)
            it.setData(SB, ("playlist", n))
            it.setData(SB + 1, "list")
            self.sidebar.addItem(it)
        it = QListWidgetItem("新しいプレイリスト")
        it.setData(SB, ("newplaylist", None))
        it.setData(SB + 1, "plus")
        self.sidebar.addItem(it)
        self.refresh_sidebar_icons()
        self.select_sidebar(keep)

    def refresh_sidebar_icons(self):
        for i in range(self.sidebar.count()):
            it = self.sidebar.item(i)
            k = it.data(SB + 1)
            if k:
                it.setIcon(make_icon(k, self.c["text"], 18))

    def select_sidebar(self, view):
        kind = view[0]
        if kind in ("album", "artist"):
            kind = kind + "s"
        for i in range(self.sidebar.count()):
            d = self.sidebar.item(i).data(SB)
            if d and (d[0], d[1]) == (kind, view[1] if kind == "playlist" else None):
                self.sidebar.blockSignals(True)
                self.sidebar.setCurrentRow(i)
                self.sidebar.blockSignals(False)
                return

    def on_sidebar(self, it):
        d = it.data(SB)
        if not d:
            return
        if d[0] == "newplaylist":
            self.new_playlist()
            return
        self.show_view(*d)

    def sidebar_menu(self, pos):
        it = self.sidebar.itemAt(pos)
        d = it.data(SB) if it else None
        if not d or d[0] != "playlist":
            return
        m = QMenu(self)
        m.addAction("名前を変える…", lambda: self.rename_playlist(d[1]))
        m.addAction("プレイリストを書き出す…", lambda: self.export_playlist(d[1]))
        m.addSeparator()
        m.addAction("削除", lambda: self.delete_playlist(d[1]))
        m.exec(self.sidebar.mapToGlobal(pos))

    # ------------------------------------------------------------------ 表示の切り替え
    def track_list_for(self, view):
        kind, arg = view
        L = self.lib
        if kind == "songs":
            return "曲", L.sorted_tracks()
        if kind == "recent":
            ts = sorted(L.tracks.values(), key=lambda t: -t.get("added", 0))[:100]
            return "最近追加した曲", ts
        if kind == "top":
            ts = sorted((t for t in L.tracks.values() if t.get("plays", 0) > 0), key=lambda t: -t.get("plays", 0))[:100]
            return "よく聞く曲", ts
        if kind == "album":
            ts = L.albums().get(tuple(arg), [])
            return (arg[0] or "不明なアルバム"), L.sorted_tracks(ts)
        if kind == "artist":
            return (arg or "不明なアーティスト"), L.sorted_tracks(L.artists().get(arg, []))
        if kind == "playlist":
            out = []
            for p in core.read_m3u(os.path.join(core.playlists_dir(), arg + ".m3u")):
                t = L.tracks.get(p)
                if t is None and os.path.isfile(p):
                    t = core.read_tags(p)
                if t is not None:
                    out.append(t)
            return arg, out
        return "曲", []

    def show_view(self, kind, arg=None):
        self.view = (kind, arg)
        self.search.blockSignals(True)
        self.search.clear()
        self.search.blockSignals(False)
        self.proxy.set_needle("")
        self.back_target = None
        self.select_sidebar(self.view)
        has = bool(self.lib.tracks) or kind == "playlist"
        self.back_btn.setVisible(kind in ("album", "artist"))
        if not self.lib.tracks and kind != "playlist":
            self.header.hide()
            self.set_empty_text()
            self.stack.setCurrentWidget(self.empty)
            return
        self.header.show()
        if kind == "albums":
            self.title_lbl.setText("アルバム")
            al = self.lib.albums()
            self.sub_lbl.setText("%d 枚" % len(al))
            self.fill_albums(al)
            self.stack.setCurrentWidget(self.albums)
            self.play_all_btn.hide(); self.shuffle_all_btn.hide()
            self.search.setPlaceholderText("アルバムを検索")
            return
        if kind == "artists":
            self.title_lbl.setText("アーティスト")
            ar = self.lib.artists()
            self.sub_lbl.setText("%d 人" % len(ar))
            self.fill_artists(ar)
            self.stack.setCurrentWidget(self.artists)
            self.play_all_btn.hide(); self.shuffle_all_btn.hide()
            self.search.setPlaceholderText("アーティストを検索")
            return
        title, tracks = self.track_list_for(self.view)
        self.title_lbl.setText(title)
        total = sum(t.get("duration", 0) for t in tracks)
        self.sub_lbl.setText("%d 曲 ・ %s" % (len(tracks), self.fmt_total(total)) if tracks else "曲がありません")
        self.model.set_tracks(tracks)
        self.model.set_playing(self.cur["path"] if self.cur else "", self.is_playing())
        self.stack.setCurrentWidget(self.table)
        self.play_all_btn.show(); self.shuffle_all_btn.show()
        self.play_all_btn.setEnabled(bool(tracks)); self.shuffle_all_btn.setEnabled(bool(tracks))
        self.search.setPlaceholderText("曲・アーティスト・アルバムを検索")
        if kind in ("album",):
            self.back_target = ("albums", None)
        elif kind == "artist":
            self.back_target = ("artists", None)

    def set_empty_text(self):
        d = self.music_dir()
        self.empty_music_btn.setVisible(bool(d))
        if d:
            self.empty_music_btn.setText("「%s」を追加" % os.path.basename(d.rstrip("/")))

    @staticmethod
    def fmt_total(sec):
        sec = int(sec)
        h, m = divmod(sec // 60, 60)
        return ("%d 時間 %d 分" % (h, m)) if h else "%d 分" % m

    def go_back(self):
        if getattr(self, "back_target", None):
            self.show_view(*self.back_target)

    def fill_albums(self, al):
        self.albums.clear()
        self.thumb_todo = []
        keys = sorted(al, key=lambda k: (core.natural_key(k[0]), core.natural_key(k[1])))
        ph = {}
        for k in keys:
            ts = core.Library.sorted_tracks(self.lib, al[k])
            it = QListWidgetItem((k[0] or "不明なアルバム") + "\n" + (k[1] or "不明なアーティスト"))
            it.setData(SB, k)
            it.setData(SB + 1, ts[0]["path"])
            it.setSizeHint(QSize(196, 236))
            it.setIcon(QIcon(placeholder(k[0] or "?", 168, self.devicePixelRatioF())))
            it.setToolTip("%s\n%s ・ %d 曲" % (k[0] or "不明なアルバム", k[1] or "不明なアーティスト", len(ts)))
            self.albums.addItem(it)
            self.thumb_todo.append(it)
        QTimer.singleShot(10, self.load_thumbs)

    def load_thumbs(self):
        n = 0
        while self.thumb_todo and n < 6:
            it = self.thumb_todo.pop(0)
            try:
                pm = self.cover_for(it.data(SB + 1), size=336)
                if pm is not None:
                    pm.setDevicePixelRatio(2.0)
                    it.setIcon(QIcon(pm))
            except RuntimeError:
                return          # 一覧が作り直された
            n += 1
        if self.thumb_todo:
            QTimer.singleShot(5, self.load_thumbs)

    def fill_artists(self, ar):
        self.artists.clear()
        for name in sorted(ar, key=core.natural_key):
            it = QListWidgetItem("%s    %d 曲" % (name or "不明なアーティスト", len(ar[name])))
            it.setData(SB, name)
            self.artists.addItem(it)

    def on_album(self, it):
        self.show_view("album", it.data(SB))

    def on_artist(self, it):
        self.show_view("artist", it.data(SB))

    def on_search(self, text):
        k = self.view[0]
        if k == "albums":
            for i in range(self.albums.count()):
                it = self.albums.item(i)
                it.setHidden(bool(text.strip()) and text.strip().lower() not in it.text().lower())
        elif k == "artists":
            for i in range(self.artists.count()):
                it = self.artists.item(i)
                it.setHidden(bool(text.strip()) and text.strip().lower() not in it.text().lower())
        else:
            self.proxy.set_needle(text)
            n = self.proxy.rowCount()
            if text.strip():
                self.sub_lbl.setText("「%s」に合う曲: %d 曲" % (text.strip(), n))
            else:
                title, tracks = self.track_list_for(self.view)
                self.sub_lbl.setText("%d 曲 ・ %s" % (len(tracks), self.fmt_total(sum(t.get("duration", 0) for t in tracks))))

    # ------------------------------------------------------------------ 曲の表の操作
    def visible_paths(self):
        return [self.proxy.index(r, 0).data(UR.UserRole) for r in range(self.proxy.rowCount())]

    def selected_paths(self):
        rows = sorted({i.row() for i in self.table.selectionModel().selectedRows()})
        return [self.proxy.index(r, 0).data(UR.UserRole) for r in rows]

    def on_table_activate(self, idx):
        paths = self.visible_paths()
        self.play_list(paths, idx.row())

    def play_visible(self, shuffle):
        paths = self.visible_paths()
        if not paths:
            return
        self.set_shuffle(shuffle)
        import random
        self.play_list(paths, random.randrange(len(paths)) if shuffle else 0)

    def table_menu(self, pos):
        idx = self.table.indexAt(pos)
        if not idx.isValid():
            return
        if not self.table.selectionModel().isRowSelected(idx.row(), idx.parent()):
            self.table.selectRow(idx.row())
        paths = self.selected_paths()
        m = QMenu(self)
        m.addAction("再生", lambda: self.play_list(self.visible_paths(), idx.row()))
        m.addAction("次に再生", lambda: self.enqueue(paths, next_=True))
        m.addAction("再生待ちに追加", lambda: self.enqueue(paths))
        sub = m.addMenu("プレイリストに追加")
        for n in core.list_playlists():
            sub.addAction(n, lambda n=n: self.add_to_playlist(n, paths))
        sub.addSeparator()
        sub.addAction("新しいプレイリスト…", lambda: self.add_to_new_playlist(paths))
        m.addSeparator()
        if len(paths) == 1:
            m.addAction("曲の情報…", lambda: self.show_info(paths[0]))
            m.addAction("ファイルのあるフォルダーを開く", lambda: self.open_folder_of(paths[0]))
        if self.view[0] == "playlist":
            m.addAction("プレイリストから外す", lambda: self.remove_from_playlist(self.view[1], paths))
        else:
            m.addAction("ライブラリから外す(ファイルは消えません)", lambda: self.remove_from_library(paths))
        m.exec(self.table.viewport().mapToGlobal(pos))

    def open_folder_of(self, path):
        try:
            subprocess.Popen(["xdg-open", os.path.dirname(path)])
        except OSError:
            pass

    def remove_from_library(self, paths):
        for p in paths:
            self.lib.tracks.pop(p, None)
        self.lib.save()
        self.show_view(*self.view)

    # ------------------------------------------------------------------ 再生
    def is_playing(self):
        return self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState

    def track_info(self, path):
        t = self.lib.tracks.get(path)
        if t is None:
            t = core.read_tags(path) if os.path.isfile(path) else {"path": path, "title": os.path.basename(path), "duration": 0}
        return t

    def play_list(self, paths, start):
        if not paths:
            return
        self.errors = 0
        self.queue.set(paths, start)
        self.start_current(True)
        self.refresh_queue()

    def start_current(self, autoplay=True, position=0):
        path = self.queue.current()
        if path is None:
            return
        self.cur = self.track_info(path)
        self.counted = False
        self.pending_seek = position
        self.player.setSource(QUrl.fromLocalFile(path))
        if autoplay:
            self.player.play()
        self.show_now_playing()

    def toggle_play(self):
        if self.player.source().isEmpty():
            if self.queue.current() is None:
                paths = self.visible_paths() if self.stack.currentWidget() is self.table else []
                if not paths:
                    paths = [t["path"] for t in self.lib.sorted_tracks()]
                if paths:
                    self.play_list(paths, 0)
                return
            self.start_current(True, self.pending_seek)
            return
        if self.is_playing():
            self.player.pause()
        else:
            self.player.play()

    def next_track(self, auto=False):
        p = self.queue.next(auto=auto)
        if p is None:
            if auto:
                self.player.stop()
                self.seek.setValue(0)
                self.t_left.setText("0:00")
                self.model.set_playing(self.cur["path"] if self.cur else "", False)
            return
        self.start_current(True)
        self.refresh_queue_marker()

    def prev_track(self):
        if self.player.position() > 3000:
            self.player.setPosition(0)
            return
        p = self.queue.prev()
        if p is not None:
            self.start_current(True)
            self.refresh_queue_marker()

    def jump_to(self, i):
        if self.queue.jump(i) is not None:
            self.errors = 0
            self.start_current(True)
            self.refresh_queue_marker()

    def seek_by(self, ms):
        if self.player.duration() > 0:
            self.player.setPosition(max(0, min(self.player.duration(), self.player.position() + ms)))

    def on_position(self, pos):
        if not self.seek.isSliderDown():
            self.seek.setValue(pos)
        self.t_left.setText(core.fmt_time(pos / 1000.0))
        self.update_right_time()
        if not self.counted and self.cur and pos > min(30000, max(5000, self.player.duration() // 2)):
            self.counted = True
            t = self.lib.tracks.get(self.cur["path"])
            if t is not None:
                t["plays"] = t.get("plays", 0) + 1
        self.sync_lyrics(pos)

    def update_right_time(self):
        d = self.player.duration()
        if self.st["show_remaining"]:
            self.t_right.setText("-" + core.fmt_time(max(0, d - self.player.position()) / 1000.0))
        else:
            self.t_right.setText(core.fmt_time(d / 1000.0))

    def on_duration(self, d):
        self.seek.setRange(0, max(0, d))
        self.update_right_time()

    def on_status(self, s):
        MS = QMediaPlayer.MediaStatus
        if s == MS.LoadedMedia and self.pending_seek:
            self.player.setPosition(self.pending_seek)
            self.pending_seek = 0
        elif s == MS.EndOfMedia:
            if self.sleep_end_of_track:
                self.set_sleep(0)
                self.player.stop()
                self.statusBar().showMessage("スリープタイマー: 曲の終わりで止めました", 5000)
                return
            self.next_track(auto=True)

    def on_state(self, _):
        self.update_play_icon()
        self.model.set_playing(self.cur["path"] if self.cur else "", self.is_playing())
        self.refresh_title()

    def on_error(self, err, msg):
        if err == QMediaPlayer.Error.NoError:
            return
        name = self.cur["title"] if self.cur else ""
        self.statusBar().showMessage("再生できません: %s(%s)" % (name, msg or "不明な理由"), 8000)
        self.errors += 1
        if self.errors < max(1, len(self.queue.items)) and self.errors < 5:
            QTimer.singleShot(400, lambda: self.next_track(auto=True))
        else:
            self.player.stop()

    def on_seek_moved(self, v):
        self.t_left.setText(core.fmt_time(v / 1000.0))

    def on_seek_released(self):
        self.player.setPosition(self.seek.value())

    # 音量・速さ
    def on_volume(self, v):
        lin = QAudio.convertVolume(v / 100.0, QAudio.VolumeScale.LogarithmicVolumeScale, QAudio.VolumeScale.LinearVolumeScale)
        if self.fade is None:
            self.audio.setVolume(lin)
        if v > 0 and self.audio.isMuted():
            self.audio.setMuted(False)
        self.update_mute_icon()
        self.vol.setToolTip("音量 %d%%" % v)

    def toggle_mute(self):
        self.audio.setMuted(not self.audio.isMuted())
        self.update_mute_icon()

    def set_rate(self, r):
        self.player.setPlaybackRate(r)
        self.rate_acts[r].setChecked(True)
        self.st["rate"] = r
        if r != 1.0:
            self.statusBar().showMessage("再生の速さ: %g 倍" % r, 3000)

    def set_shuffle(self, on=None):
        if on is None or isinstance(on, bool) is False:
            on = self.btn_shuffle.isChecked()
        self.queue.set_shuffle(bool(on))
        self.btn_shuffle.setChecked(bool(on))
        self.act_shuffle.setChecked(bool(on))
        self.btn_shuffle.setIcon(self.ic("shuffle", self.c["accent"] if on else self.c["text"], 22))
        self.btn_shuffle.setToolTip("シャッフル: " + ("入" if on else "切") + " (S)")

    def cycle_repeat(self):
        self.queue.repeat = {"off": "all", "all": "one", "one": "off"}[self.queue.repeat]
        self.update_repeat_icon()
        self.statusBar().showMessage("リピート: " + {"off": "なし", "all": "全曲", "one": "1曲"}[self.queue.repeat], 2500)

    # ------------------------------------------------------------------ 再生中の表示
    def show_now_playing(self):
        t = self.cur
        if not t:
            return
        self.now_title.setText(t.get("title", ""))
        self.now_sub.setText(" ・ ".join(x for x in (t.get("artist") or "", t.get("album") or "") if x) or "不明なアーティスト")
        self.p_title.setText(t.get("title", ""))
        self.p_artist.setText(core.display(t, "artist"))
        self.p_album.setText(core.display(t, "album") + ("  (%s)" % t["year"] if t.get("year") else ""))
        pm = self.cover_for(t["path"], size=600)
        name = t.get("album") or t.get("title", "")
        self.big_cover.set_cover(pm, name)
        self.mini_cover.set_cover(pm, name)
        self.refresh_title()
        self.model.set_playing(t["path"], self.is_playing())
        self.load_lyrics(t["path"])
        self.refresh_queue_marker()

    def refresh_title(self):
        if self.cur:
            self.setWindowTitle("%s%s — %s" % ("" if self.is_playing() else "(一時停止) ", self.cur.get("title", ""), APP_NAME))
        else:
            self.setWindowTitle(APP_NAME)

    def cover_for(self, path, size=600):
        t = self.lib.tracks.get(path) or {}
        key = ((t.get("album") or "") + "|" + (t.get("albumartist") or t.get("artist") or ""), size) if t.get("album") else (path, size)
        if key in self.cover_cache:
            return self.cover_cache[key]
        pm = None
        data = core.read_cover(path)
        if data:
            img = QPixmap()
            if img.loadFromData(data) and not img.isNull():
                pm = img.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation) if min(img.width(), img.height()) > size else img
        if len(self.cover_cache) > 400:
            self.cover_cache.clear()
        self.cover_cache[key] = pm
        return pm

    # 歌詞
    def load_lyrics(self, path):
        self.lyrics = core.read_lyrics(path)
        self.lyrics_list.clear()
        self.lyric_row = -1
        if not self.lyrics:
            it = QListWidgetItem("歌詞はありません。\n\n曲と同じ名前の .lrc ファイルを同じフォルダーに置くと、歌に合わせて表示されます。")
            it.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            it.setFlags(Qt.ItemFlag.NoItemFlags)
            self.lyrics_list.addItem(it)
            return
        synced = self.lyrics[0][0] is not None
        for ms, line in self.lyrics:
            it = QListWidgetItem(line or " ")
            it.setTextAlignment(Qt.AlignmentFlag.AlignCenter if synced else Qt.AlignmentFlag.AlignLeft)
            it.setData(SB, ms)
            it.setForeground(QColor(self.c["sub2"]) if synced else QColor(self.c["text"]))
            f = QFont(); f.setPointSizeF(self.font().pointSizeF() + 1)
            it.setFont(f)
            self.lyrics_list.addItem(it)

    def sync_lyrics(self, pos):
        if not self.lyrics or self.lyrics[0][0] is None:
            return
        i = core.lyric_index(self.lyrics, pos)
        if i == self.lyric_row:
            return
        if 0 <= self.lyric_row < self.lyrics_list.count():
            it = self.lyrics_list.item(self.lyric_row)
            f = it.font(); f.setBold(False); f.setPointSizeF(self.font().pointSizeF() + 1); it.setFont(f)
            it.setForeground(QColor(self.c["sub2"]))
        self.lyric_row = i
        if i >= 0:
            it = self.lyrics_list.item(i)
            f = it.font(); f.setBold(True); f.setPointSizeF(self.font().pointSizeF() + 4); it.setFont(f)
            it.setForeground(QColor(self.c["accent"]))
            self.lyrics_list.scrollToItem(it, QAbstractItemView.ScrollHint.PositionAtCenter)

    def on_lyric_click(self, it):
        ms = it.data(SB)
        if ms is not None:
            self.player.setPosition(int(ms))

    # 再生待ち
    def refresh_queue(self):
        self.queue_list.blockSignals(True)
        self.queue_list.clear()
        for i, p in enumerate(self.queue.items):
            t = self.track_info(p)
            it = QListWidgetItem("%s\n%s" % (t.get("title", ""), core.display(t, "artist")))
            it.setToolTip(t.get("title", ""))
            self.queue_list.addItem(it)
        self.queue_list.blockSignals(False)
        self.queue_lbl.setText("再生待ち: %d 曲" % len(self.queue.items))
        self.refresh_queue_marker()

    def refresh_queue_marker(self):
        for i in range(self.queue_list.count()):
            it = self.queue_list.item(i)
            f = it.font(); f.setBold(i == self.queue.cur); it.setFont(f)
            it.setForeground(QColor(self.c["accent"]) if i == self.queue.cur else QColor(self.c["text"]))
        if 0 <= self.queue.cur < self.queue_list.count():
            self.queue_list.scrollToItem(self.queue_list.item(self.queue.cur))

    def on_queue_moved(self, parent, start, end, dest, row):
        dst = row - 1 if row > start else row
        QTimer.singleShot(0, lambda: (self.queue.move(start, dst), self.refresh_queue()))

    def clear_queue(self):
        keep = self.queue.current()
        self.queue.set([keep] if keep else [], 0)
        self.refresh_queue()

    def queue_menu(self, pos):
        rows = sorted({self.queue_list.row(i) for i in self.queue_list.selectedItems()})
        if not rows:
            return
        m = QMenu(self)
        m.addAction("再生待ちから外す", lambda: self.remove_from_queue(rows))
        m.exec(self.queue_list.viewport().mapToGlobal(pos))

    def remove_from_queue(self, rows):
        for r in reversed(rows):
            was_cur = (r == self.queue.cur)
            self.queue.remove(r)
            if was_cur:
                self.player.stop()
        self.refresh_queue()

    def enqueue(self, paths, next_=False):
        if self.queue.current() is None and not self.queue.items:
            self.play_list(paths, 0)
            return
        for p in (reversed(paths) if next_ else paths):
            (self.queue.play_next if next_ else self.queue.append)(p)
        self.refresh_queue()
        self.statusBar().showMessage("%d 曲を、再生待ちに%s" % (len(paths), "入れました(次に再生)" if next_ else "追加しました"), 3000)

    def show_panel_tab(self, i):
        if not self.panel.isVisible():
            self.toggle_panel()
        self.tabs.setCurrentIndex(i)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Delete and self.queue_list.hasFocus():
            rows = sorted({self.queue_list.row(i) for i in self.queue_list.selectedItems()})
            if rows:
                self.remove_from_queue(rows)
                return
        super().keyPressEvent(e)

    # ------------------------------------------------------------------ プレイリスト
    def pl_path(self, name):
        return os.path.join(core.playlists_dir(), core.safe_name(name) + ".m3u")

    def new_playlist(self, paths=None):
        name, ok = QInputDialog.getText(self, "新しいプレイリスト", "プレイリストの名前")
        if not ok or not name.strip():
            return None
        name = core.safe_name(name)
        p = self.pl_path(name)
        if os.path.exists(p) and QMessageBox.question(self, "確認", "「%s」はすでにあります。上書きしますか?" % name) != QMessageBox.StandardButton.Yes:
            return None
        core.write_m3u(p, [self.track_info(x) for x in (paths or [])])
        self.refresh_sidebar()
        self.show_view("playlist", name)
        return name

    def add_to_new_playlist(self, paths):
        self.new_playlist(paths)

    def add_to_playlist(self, name, paths):
        p = self.pl_path(name)
        cur = core.read_m3u(p)
        tracks = [self.track_info(x) for x in cur + [q for q in paths if q not in cur]]
        core.write_m3u(p, tracks)
        self.statusBar().showMessage("「%s」に %d 曲を追加しました" % (name, len(paths)), 3000)
        if self.view == ("playlist", name):
            self.show_view("playlist", name)

    def remove_from_playlist(self, name, paths):
        p = self.pl_path(name)
        keep = [x for x in core.read_m3u(p) if x not in set(paths)]
        core.write_m3u(p, [self.track_info(x) for x in keep])
        self.show_view("playlist", name)

    def rename_playlist(self, name):
        new, ok = QInputDialog.getText(self, "名前を変える", "新しい名前", text=name)
        if ok and new.strip() and core.safe_name(new) != name:
            os.replace(self.pl_path(name), self.pl_path(new))
            self.refresh_sidebar()
            self.show_view("playlist", core.safe_name(new))

    def delete_playlist(self, name):
        if QMessageBox.question(self, "削除", "プレイリスト「%s」を削除しますか?\n(曲のファイルは消えません)" % name) == QMessageBox.StandardButton.Yes:
            try:
                os.remove(self.pl_path(name))
            except OSError:
                pass
            self.view = ("songs", None)
            self.refresh_sidebar()
            self.show_view("songs")

    def export_playlist(self, name):
        dst, _ = QFileDialog.getSaveFileName(self, "プレイリストを書き出す", os.path.expanduser("~/%s.m3u" % name), "プレイリスト (*.m3u)")
        if dst:
            core.write_m3u(dst, [self.track_info(x) for x in core.read_m3u(self.pl_path(name))])

    def open_playlist_file(self):
        f, _ = QFileDialog.getOpenFileName(self, "プレイリストを開く", os.path.expanduser("~"), "プレイリスト (*.m3u *.m3u8)")
        if not f:
            return
        paths = [p for p in core.read_m3u(f) if os.path.isfile(p)]
        if not paths:
            QMessageBox.information(self, APP_NAME, "このプレイリストに、再生できる曲が見つかりませんでした。")
            return
        self.lib.add_files(paths)
        self.play_list(paths, 0)

    # ------------------------------------------------------------------ ライブラリ
    @staticmethod
    def music_dir():
        try:
            d = subprocess.run(["xdg-user-dir", "MUSIC"], capture_output=True, text=True, timeout=3).stdout.strip()
        except Exception:
            d = ""
        for c in (d, os.path.expanduser("~/Music"), os.path.expanduser("~/ミュージック")):
            if c and os.path.isdir(c) and c != os.path.expanduser("~"):
                return c
        return ""

    def add_music_dir(self):
        d = self.music_dir()
        if d:
            self.add_folder(d)

    def add_folder_dialog(self):
        d = QFileDialog.getExistingDirectory(self, "音楽のフォルダーを選ぶ", self.music_dir() or os.path.expanduser("~"))
        if d:
            self.add_folder(d)

    def add_folder(self, d):
        self.lib.add_folder(d)
        self.lib.save()
        self.rescan()

    def add_files_dialog(self):
        fs, _ = QFileDialog.getOpenFileNames(self, "曲のファイルを開く", self.music_dir() or os.path.expanduser("~"),
                                             "音楽ファイル (%s);;すべてのファイル (*)" % " ".join("*" + e for e in sorted(core.AUDIO_EXT)))
        if fs:
            self.open_paths(fs)

    def manage_folders(self):
        d = QDialog(self)
        d.setWindowTitle("ライブラリのフォルダー")
        d.resize(520, 340)
        v = QVBoxLayout(d)
        v.addWidget(QLabel("このフォルダーの中の曲が、ライブラリに入ります。"))
        lw = QListWidget()
        lw.addItems(self.lib.folders)
        v.addWidget(lw, 1)
        h = QHBoxLayout()
        add = QPushButton("追加…")
        rem = QPushButton("外す")
        close = QPushButton("閉じる")
        close.setObjectName("primary")
        h.addWidget(add); h.addWidget(rem); h.addStretch(1); h.addWidget(close)
        v.addLayout(h)

        def do_add():
            x = QFileDialog.getExistingDirectory(d, "音楽のフォルダーを選ぶ", self.music_dir() or os.path.expanduser("~"))
            if x:
                self.lib.add_folder(x)
                lw.clear(); lw.addItems(self.lib.folders)

        def do_rem():
            it = lw.currentItem()
            if it:
                self.lib.remove_folder(it.text())
                lw.clear(); lw.addItems(self.lib.folders)
        add.clicked.connect(do_add)
        rem.clicked.connect(do_rem)
        close.clicked.connect(d.accept)
        d.exec()
        self.lib.save()
        self.rescan()

    def rescan(self):
        if self.scan_thread is not None and self.scan_thread.isRunning():
            return
        if not self.lib.folders:
            self.show_view(*self.view)
            return
        self.scan_lbl.setText("ライブラリを読み込み中…")
        self.scan_thread = ScanThread(self.lib.clone(), self)
        self.scan_thread.progress.connect(lambda n, p: self.scan_lbl.setText("ライブラリを読み込み中… %d 曲" % n))
        self.scan_thread.finished_scan.connect(self.on_scanned)
        self.scan_thread.start()

    def on_scanned(self, lib, a, u, r):
        new = lib.tracks
        for p, t in self.lib.tracks.items():          # ライブラリのフォルダーの外から、個別に開いた曲は残す
            if p not in new and not any(p.startswith(f.rstrip("/") + "/") for f in self.lib.folders):
                new[p] = t
        self.lib.tracks = new
        self.lib.save()
        self.scan_lbl.setText("")
        msg = "ライブラリ: 全 %d 曲" % len(new)
        if a or u or r:
            msg += "(追加 %d・更新 %d・削除 %d)" % (a, u, r)
        self.statusBar().showMessage(msg, 6000)
        self.refresh_sidebar()
        if self.view[0] not in ("playlist",) or True:
            self.show_view(*self.view)

    # 外から渡された曲・フォルダー
    def open_paths(self, paths):
        files, dirs = [], []
        for p in paths:
            p = os.path.abspath(p)
            (dirs if os.path.isdir(p) else files).append(p)
        for d in dirs:
            self.lib.add_folder(d)
        if dirs:
            self.lib.save()
            self.rescan()
        files = self.lib.add_files(files)
        if files:
            self.lib.save()
            self.play_list(files, 0)
            if self.view[0] in ("songs", "recent"):
                self.show_view(*self.view)

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        self.open_paths([u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()])
        self.raise_()

    # ------------------------------------------------------------------ スリープタイマー
    def set_sleep(self, mins):
        if self.fade is not None:
            self.fade.stop(); self.fade = None
            self.on_volume(self.vol.value())
        self.sleep_end_of_track = (mins == -1)
        self.sleep_left = mins * 60 if mins > 0 else 0
        self.sleep_acts[{0: 0, 15: 1, 30: 2, 60: 3, 90: 4, -1: 5}[mins]].setChecked(True)
        self.update_sleep_label()
        if mins:
            self.statusBar().showMessage("スリープタイマー: " + ("この曲の終わりで止めます" if mins < 0 else "%d 分後に止めます" % mins), 4000)

    def update_sleep_label(self):
        if self.sleep_end_of_track:
            self.sleep_lbl.setText("曲の終わりで停止")
        elif self.sleep_left > 0:
            self.sleep_lbl.setText("停止まで " + core.fmt_time(self.sleep_left))
        else:
            self.sleep_lbl.setText("")

    def tick(self):
        if self.sleep_left > 0:
            self.sleep_left -= 1
            self.update_sleep_label()
            if self.sleep_left == 0:
                self.start_fade()

    def start_fade(self):
        """3 秒かけて音を小さくして、止める。"""
        steps = {"n": 10}
        base = self.audio.volume()
        t = QTimer(self)
        self.fade = t

        def step():
            steps["n"] -= 1
            self.audio.setVolume(base * steps["n"] / 10.0)
            if steps["n"] <= 0:
                t.stop()
                self.fade = None
                self.player.pause()
                self.on_volume(self.vol.value())
                self.set_sleep(0)
                self.statusBar().showMessage("スリープタイマーで止めました", 6000)
        t.timeout.connect(step)
        t.start(300)

    # ------------------------------------------------------------------ 表示の切り替え
    def toggle_panel(self, *_):
        vis = not self.panel.isVisible()
        self.panel.setVisible(vis)
        self.btn_panel.setChecked(vis)
        self.act_panel.setChecked(vis)
        self.st["panel"] = vis

    def toggle_top(self):
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, self.act_top.isChecked())
        self.show()

    def toggle_mini(self):
        if not self.mini:
            self.normal_geo = self.saveGeometry()
            self.mini = True
            self.menuBar().hide()
            self.statusBar().hide()
            self.sidebar.hide()
            self.panel.hide()
            self.stack.hide()
            self.header.hide()
            self.setMinimumSize(0, 0)
            self.setFixedHeight(self.bar.height())
            self.setMinimumWidth(940)
            self.setMaximumWidth(16777215)
            self.resize(940, self.bar.height())
        else:
            self.mini = False
            self.setMinimumSize(980, 580)
            self.setMaximumSize(16777215, 16777215)
            self.menuBar().show()
            self.statusBar().show()
            self.sidebar.show()
            self.stack.show()
            if self.view[0] not in ("albums", "artists") and self.lib.tracks:
                self.header.show()
            elif self.lib.tracks:
                self.header.show()
            self.panel.setVisible(self.st["panel"])
            if self.normal_geo:
                self.restoreGeometry(self.normal_geo)
            self.resize(max(self.width(), 980), max(self.height(), 580))

    # ------------------------------------------------------------------ ダイアログ
    def show_info(self, path):
        t = self.track_info(path)
        d = QDialog(self)
        d.setWindowTitle("曲の情報")
        d.setMinimumWidth(520)
        v = QVBoxLayout(d)
        h = QHBoxLayout()
        cv = CoverLabel(120, 8)
        cv.set_cover(self.cover_for(path, 300), t.get("album") or t.get("title", ""))
        h.addWidget(cv, 0, Qt.AlignmentFlag.AlignTop)
        f = QFormLayout()
        f.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        def row(label, text):
            l = QLabel(text)
            l.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            l.setWordWrap(True)
            f.addRow(label + ":", l)
        row("タイトル", t.get("title", ""))
        row("アーティスト", core.display(t, "artist"))
        row("アルバム", core.display(t, "album"))
        if t.get("albumartist"):
            row("アルバムのアーティスト", t["albumartist"])
        if t.get("track"):
            row("トラック", ("%d" % t["track"]) + (" (ディスク %d)" % t["disc"] if t.get("disc") else ""))
        if t.get("year"):
            row("年", t["year"])
        if t.get("genre"):
            row("ジャンル", t["genre"])
        row("長さ", core.fmt_time(t.get("duration", 0)))
        row("形式", t.get("format", "") + (" ・ %d kbps" % (t["bitrate"] // 1000) if t.get("bitrate") else ""))
        row("再生回数", "%d 回" % self.lib.tracks.get(path, {}).get("plays", 0))
        row("場所", path)
        h.addLayout(f, 1)
        v.addLayout(h)
        b = QPushButton("閉じる")
        b.setObjectName("primary")
        b.clicked.connect(d.accept)
        v.addWidget(b, 0, Qt.AlignmentFlag.AlignRight)
        d.exec()

    def show_keys(self):
        rows = [("Space", "再生 / 一時停止"), ("Ctrl+→ / Ctrl+←", "次の曲 / 前の曲(3 秒以上たっていれば、曲の頭へ)"),
                ("Alt+→ / Alt+←", "5 秒進む / 戻る"), ("Ctrl+↑ / Ctrl+↓", "音量を上げる / 下げる"), ("M", "ミュート"),
                ("S / R", "シャッフル / リピートの切り替え"), ("Ctrl+F", "検索"), ("Ctrl+1 / 2 / 3", "曲 / アルバム / アーティスト"),
                ("F2", "ミニプレーヤー"), ("F3", "再生中パネルの表示 / 非表示"), ("Ctrl+L / Ctrl+J", "歌詞 / 再生待ち"),
                ("F5", "ライブラリを読み込み直す"), ("Ctrl+O", "ファイルを開く"), ("Ctrl+Shift+O", "フォルダーを追加"),
                ("Enter / ダブルクリック", "選んだ曲を再生"), ("Delete", "(再生待ちで)選んだ曲を外す")]
        d = QDialog(self)
        d.setWindowTitle("キーボードの操作一覧")
        v = QVBoxLayout(d)
        f = QFormLayout()
        for k, t in rows:
            kl = QLabel("<b>%s</b>" % k)
            f.addRow(kl, QLabel(t))
        v.addLayout(f)
        b = QPushButton("閉じる")
        b.setObjectName("primary")
        b.clicked.connect(d.accept)
        v.addWidget(b, 0, Qt.AlignmentFlag.AlignRight)
        d.exec()

    def show_about(self):
        QMessageBox.about(self, APP_NAME, "<h3>%s</h3><p>qwerty-os の、軽くて見やすい音楽プレーヤーです。</p>"
                          "<p>mp3・flac・ogg・opus・m4a・wav などを再生できます。歌詞(.lrc)・プレイリスト(.m3u)・スリープタイマーに対応しています。</p>" % APP_NAME)

    # ------------------------------------------------------------------ 起動・終了
    def restore(self):
        s = self.st
        self.vol.setValue(int(s["volume"]))
        self.on_volume(self.vol.value())
        self.audio.setMuted(bool(s["muted"]))
        self.update_mute_icon()
        self.set_shuffle(bool(s["shuffle"]))
        self.queue.repeat = s["repeat"] if s["repeat"] in ("off", "all", "one") else "off"
        self.update_repeat_icon()
        r = float(s["rate"] or 1.0)
        self.rate_acts.get(r, self.rate_acts[1.0]).setChecked(True)
        if r in self.rate_acts:
            self.player.setPlaybackRate(r)
        self.panel.setVisible(bool(s["panel"]))
        self.btn_panel.setChecked(bool(s["panel"]))
        self.act_panel.setChecked(bool(s["panel"]))
        self.tabs.setCurrentIndex(int(s["panel_tab"] or 0))
        if s["geometry"]:
            try:
                self.restoreGeometry(base64.b64decode(s["geometry"]))
            except Exception:
                pass
        q = [p for p in s["queue"] if os.path.isfile(p)]
        if q:
            idx = s["index"] if 0 <= s["index"] < len(s["queue"]) else 0
            cur = s["queue"][idx] if idx < len(s["queue"]) else q[0]
            start = q.index(cur) if cur in q else 0
            self.queue.set(q, start)
            self.start_current(False, int(s["position"] or 0))
            self.refresh_queue()
        v = s["view"]
        self.show_view(*(tuple(v) if isinstance(v, list) and len(v) == 2 and v[0] in ("songs", "albums", "artists", "recent", "top") else ("songs", None)))

    def save_state(self):
        s = self.st
        s["volume"] = self.vol.value()
        s["muted"] = self.audio.isMuted()
        s["shuffle"] = self.queue.shuffle
        s["repeat"] = self.queue.repeat
        s["queue"] = self.queue.items[:2000]
        s["index"] = self.queue.cur
        s["position"] = int(self.player.position())
        s["panel"] = self.panel.isVisible() if not self.mini else s["panel"]
        s["panel_tab"] = self.tabs.currentIndex()
        s["view"] = list(self.view) if self.view[0] in ("songs", "albums", "artists", "recent", "top") else ["songs", None]
        g = self.normal_geo if self.mini and self.normal_geo else self.saveGeometry()
        s["geometry"] = base64.b64encode(bytes(g)).decode("ascii")
        s.save()
        try:
            self.lib.save()
        except OSError:
            pass

    def closeEvent(self, e):
        if self.scan_thread is not None and self.scan_thread.isRunning():
            self.scan_thread.stop = True
            self.scan_thread.wait(3000)
        self.save_state()
        self.player.stop()
        super().closeEvent(e)

    # 時間表示の切り替え・Space
    def fit_columns(self):
        w = self.table.viewport().width()
        if w < 200:
            return
        rest = w - 34 - 80
        a = max(110, int(rest * 0.26))
        self.table.setColumnWidth(2, a)
        self.table.setColumnWidth(3, max(110, int(rest * 0.27)))

    def fit_panel(self):
        """窓の高さに合わせて、再生中パネルの絵の大きさを決める(文字と重ならないように)。"""
        h = self.panel.height()
        side = max(96, min(264, h - 330))
        if self.big_cover.width() != side:
            self.big_cover.resizeTo(side)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.fit_panel()
        QTimer.singleShot(0, self.fit_columns)

    def showEvent(self, e):
        super().showEvent(e)
        QTimer.singleShot(0, self.fit_panel)
        QTimer.singleShot(0, self.fit_columns)

    def eventFilter(self, obj, ev):
        if obj is self.table.viewport() and ev.type() == QEvent.Type.Resize:
            QTimer.singleShot(0, self.fit_columns)
            return False
        if obj is getattr(self, "t_right", None) and ev.type() == QEvent.Type.MouseButtonRelease:
            self.st["show_remaining"] = not self.st["show_remaining"]
            self.update_right_time()
            return True
        return super().eventFilter(obj, ev)
