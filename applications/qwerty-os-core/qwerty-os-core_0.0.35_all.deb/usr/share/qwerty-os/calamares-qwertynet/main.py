#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# qwerty-os のインストーラー(Calamares)の手順: 追加するアプリが、インターネットを必要とするとき、つながっていなければ、接続するかを聞く。
#   - 何も選ばれていない・すでにつながっている → 何も聞かずに、続ける
#   - つながっていない → 「接続しますか?」 はい: かんたんな接続の画面(qwerty-wifi-simple)を出し、閉じたら、もう一度確認 / いいえ: 追加アプリは、入れずに、続ける
import os
import socket
import subprocess
import time

import libcalamares

QUESTION = ("選択された追加アプリは、インターネット接続が必要ですが、いまは、つながっていません。\n"
            "インターネット接続を行いますか?\n\n"
            "「いいえ」を選ぶと、追加アプリは入れずに、インストールを続けます。\n"
            "(あとで、アプリパッケージストアから入れられます)")


def pretty_name():
    return "インターネット接続の確認"


def selected_count():
    if not libcalamares.globalstorage.contains("packageOperations"):
        return 0
    n = 0
    for op in libcalamares.globalstorage.value("packageOperations") or []:
        if isinstance(op, dict):
            n += len(op.get("install") or []) + len(op.get("try_install") or [])
    return n


def online():
    cmd = os.environ.get("QWERTY_NETCHECK")
    if cmd:
        return subprocess.run(cmd, shell=True).returncode == 0
    for host in ("deb.debian.org", "ftp.jp.debian.org"):
        try:
            socket.create_connection((host, 443), timeout=4).close()
            return True
        except OSError:
            pass
    return False


def ask():
    r = subprocess.run(["yad", "--center", "--on-top", "--title=qwerty-os", "--width=520", "--text=" + QUESTION,
                        "--button=はい:0", "--button=いいえ:1"], stdin=subprocess.DEVNULL)
    return r.returncode == 0


def open_network_ui():
    user = os.environ.get("SUDO_USER") or "user"
    env = ["env", "DISPLAY=" + os.environ.get("DISPLAY", ":0")]
    if os.environ.get("XAUTHORITY"):
        env.append("XAUTHORITY=" + os.environ["XAUTHORITY"])
    subprocess.run(["runuser", "-u", user, "--"] + env + ["qwerty-wifi-simple"], stdin=subprocess.DEVNULL)
    for _ in range(8):          # 閉じたあと、つながるまで、少し待つ
        if online():
            return
        time.sleep(2)


def drop_installs():
    ops = libcalamares.globalstorage.value("packageOperations") or []
    keep = [op for op in ops if isinstance(op, dict) and not (op.get("install") or op.get("try_install"))]
    libcalamares.globalstorage.insert("packageOperations", keep)


def run():
    if selected_count() == 0:
        return None
    while not online():
        if not ask():
            libcalamares.utils.warning("追加アプリは、インターネットに接続しないため、入れない")
            drop_installs()
            return None
        open_network_ui()
    return None
