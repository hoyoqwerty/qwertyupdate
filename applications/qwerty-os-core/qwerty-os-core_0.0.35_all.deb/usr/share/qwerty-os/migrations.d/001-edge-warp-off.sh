#!/bin/sh
# ウィンドウを画面の端へ寄せて整列(qwerty-snap)するとき、画面の端に触れて、仮想デスクトップが切り替わらないよう、
# Openbox の「画面の端での切り替え(screenEdgeWarpTime)」を、無効(0)にする。
# (新しい利用者の初期設定は、すでに 0。更新前から使っている環境は、古い値(400)が残っているため)
rc=${QWERTY_OPENBOX_RC:-$HOME/.config/openbox/rc.xml}
[ -f "$rc" ] || exit 0
if grep -q '<screenEdgeWarpTime>0</screenEdgeWarpTime>' "$rc"; then exit 0; fi
if grep -q '<screenEdgeWarpTime>' "$rc"; then
    [ -e "$rc.qwerty-bak" ] || cp -p "$rc" "$rc.qwerty-bak"
    sed -i 's#<screenEdgeWarpTime>[0-9]*</screenEdgeWarpTime>#<screenEdgeWarpTime>0</screenEdgeWarpTime>#' "$rc" || exit 1
    [ -n "$QWERTY_NO_RECONFIGURE" ] || openbox --reconfigure >/dev/null 2>&1 || true
fi
exit 0
