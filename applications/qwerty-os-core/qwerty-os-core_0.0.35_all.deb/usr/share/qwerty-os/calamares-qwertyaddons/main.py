#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# qwerty-os のインストーラー(Calamares)の手順: 「追加するアプリ」で選ばれたものを、インストール先へ入れる。
#   Calamares 標準の packages 手順は、使わない(理由: インターネットの有無の判定(hasInternet)が、設定されておらず、
#   「つながっていない」とみなして、全部、飛ばしてしまった。また、1 つでも、入れられないものがあると、全部、失敗してしまう)。
#   1. 選ばれたものを集める(packageOperations の install / try_install)→ 標準の手順に、二重に処理されないよう、取り除く
#   2. インストール先の、名前解決(DNS)を、使えるようにする(インストール先の /run は空のため、resolv.conf が、切れていることがある)
#   3. apt-get update → まとめて入れる。失敗したら、1 つずつ入れ直す(入らないものがあっても、ほかは入る)
#   4. 結果を、記録する(インストール先の /var/log/qwerty-addons-install.log)。失敗があっても、インストール自体は、失敗にしない
import os
import subprocess
import time

import libcalamares

ENV = ["env", "DEBIAN_FRONTEND=noninteractive"]
OPTS = ["-y", "-o", "Dpkg::Options::=--force-confold", "-o", "Dpkg::Options::=--force-confdef"]
ENGINE_PREFIX = "qwertyengine-"
ENGINE = os.environ.get("QWERTY_ADDONS_ENGINE", "/usr/local/sbin/qwerty-update-engine")
ENGINE_SOURCE = os.environ.get("QWERTY_ADDONS_SOURCE", "/run/live/medium")      # ライブ起動の ISO(ここに qwerty-repo がある)
# 公式の置き場から直接取るもの(Google Chrome・Discord・Edge・Brave・Vivaldi・Opera)は、ISO からは入れられないので、インターネットを更新元にする
ONLINE_IDS = ("chrome", "discord", "edge", "brave", "vivaldi", "opera")
RESOLV_CANDIDATES = ("/run/systemd/resolve/resolv.conf", "/run/NetworkManager/resolv.conf", "/etc/resolv.conf")


def pretty_name():
    return "追加するアプリのインストール"


def collect():
    """選ばれたパッケージ名(重複なし・順序を保つ)。標準の手順に、重ねて処理されないよう、入れる指示は、取り除く。"""
    names = []
    gs = libcalamares.globalstorage
    if not gs.contains("packageOperations"):
        return names
    keep = []
    for op in gs.value("packageOperations") or []:
        if isinstance(op, dict) and (op.get("install") or op.get("try_install")):
            for key in ("install", "try_install"):
                for p in op.get(key) or []:
                    p = p.get("package") if isinstance(p, dict) else p
                    if p and p not in names:
                        names.append(p)
            rest = {k: v for k, v in op.items() if k not in ("install", "try_install")}
            if any(k != "source" for k in rest):          # (source は、netinstall が付ける、出所の印。残りが無ければ、捨てる)
                keep.append(rest)
        else:
            keep.append(op)
    gs.insert("packageOperations", keep)
    return names


def root_dir():
    return libcalamares.globalstorage.value("rootMountPoint")


def host_resolv():
    for p in RESOLV_CANDIDATES:
        try:
            with open(p, "rb") as f:
                data = f.read()
        except OSError:
            continue
        if b"nameserver" in data:
            return data
    return None


def dns_on(root):
    """インストール先の resolv.conf を、一時的に、動くものにする。元の状態を返す(dns_off に渡す)。"""
    path = os.path.join(root, "etc/resolv.conf")
    data = host_resolv()
    if data is None:
        return None
    saved = ("none", None)
    if os.path.islink(path):
        saved = ("link", os.readlink(path))
        os.unlink(path)
    elif os.path.exists(path):
        with open(path, "rb") as f:
            saved = ("file", f.read())
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(data)
    return (path, saved)


def dns_off(state):
    if not state:
        return
    path, (kind, val) = state
    try:
        if os.path.lexists(path):
            os.unlink(path)
        if kind == "link":
            os.symlink(val, path)
        elif kind == "file":
            with open(path, "wb") as f:
                f.write(val)
    except OSError:
        pass


def apt(args):
    return libcalamares.utils.target_env_call(ENV + ["apt-get"] + args)


def install(names, log):
    """まとめて入れる。失敗したら、1 つずつ。(入れられなかった名前の一覧を返す)"""
    if apt(["update"]) != 0:
        log("apt-get update に失敗(つながっていない可能性)")
    if apt(["install"] + OPTS + names) == 0:
        log("まとめて、入れました: %d 件" % len(names))
        return []
    log("まとめては、入れられなかったため、1 つずつ入れ直します")
    failed = []
    for n in names:
        if apt(["install"] + OPTS + [n]) == 0:
            log("入った: " + n)
        else:
            log("入らなかった: " + n)
            failed.append(n)
    return failed


def engine_install(ids, root, log):
    """Google Chrome・Discord・Edge・Brave・Vivaldi・Opera・OpenHSP・qwerty-* の専用アプリを、更新エンジンで、インストール先へ入れる(アプリパッケージストアと同じやり方)。
    入れられなかった id の一覧を返す。"""
    failed = []
    for i in ids:
        cmd = [ENGINE, "upgrade", "--source", "online" if i in ONLINE_IDS else ENGINE_SOURCE, "--groups", "add-" + i, "--root", root]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=1500)
            rc, out = r.returncode, (r.stdout or "") + (r.stderr or "")
        except (OSError, subprocess.TimeoutExpired) as e:
            rc, out = 1, str(e)
        if rc == 0:
            log("入った(更新エンジン): " + i)
        else:
            log("入らなかった(更新エンジン): %s %s" % (i, out.strip().splitlines()[-1][:200] if out.strip() else ""))
            failed.append(i)
    return failed


def run():
    names = collect()
    if not names:
        return None
    engine_ids = [n[len(ENGINE_PREFIX):] for n in names if n.startswith(ENGINE_PREFIX)]
    names = [n for n in names if not n.startswith(ENGINE_PREFIX)]
    root = root_dir()
    lines = []

    def log(m):
        libcalamares.utils.debug("qwertyaddons: " + m)
        lines.append(time.strftime("%Y-%m-%d %H:%M:%S ") + m)

    log("選ばれたアプリ(パッケージ): " + " ".join(names))
    state = dns_on(root) if root else None
    failed = []
    try:
        if names:
            failed = install(names, log)
        if engine_ids and root:
            failed += engine_install(engine_ids, root, log)
    finally:
        dns_off(state)
    if failed:
        log("入れられなかったもの: " + " ".join(failed) + "(あとで、アプリパッケージストアから、入れ直せます)")
        libcalamares.utils.warning("入れられなかった追加アプリ: " + " ".join(failed))
    try:
        d = os.path.join(root, "var/log")
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "qwerty-addons-install.log"), "a", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
    except OSError:
        pass
    return None
