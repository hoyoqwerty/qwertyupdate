#!/usr/bin/env python3
"""インストーラー(Calamares)を qwerty-os 用に整える。ISO を作るときに、ルートの中で実行される(ビルドは止めない)。
   python3 setup.py [ルート(省略時は /)]
 - 表示(題名・製品名・URL・画像・色・スライドの文字)を qwerty-os にする
 - 初期値を日本仕様にする(所在地=日本/東京、GeoIP は使わない)
 - パスワードの強度チェック(辞書チェック)で進めなくなるのをやめる(弱いパスワードを許す)
 設定ファイルの中身は Calamares のバージョンで違うので、見つかったものだけを書き換える。"""
import glob
import os
import re
import sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else "/"
NAME = "qwerty-os"


def p(*parts):
    return os.path.join(ROOT, *[x.lstrip("/") for x in parts])


def read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def write(path, text):
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def version():
    try:
        return read(p("usr/share/qwerty-os/VERSION")).strip()
    except OSError:
        return ""


def set_scalar(text, key, value, indent="", only_existing=False):
    """「key: 値」の 1 行を、value に置き換える。なければ(only_existing でなければ)最後に足す。"""
    # only_existing のときは、字下げの深さは問わない(Calamares の設定は、2 でも 3 でも 4 でも字下げされている)
    lead = r"[ \t]*" if only_existing else re.escape(indent)
    pat = re.compile(r"^(%s%s:)[ \t]*.*$" % (lead, re.escape(key)), re.M)
    if pat.search(text):
        return pat.sub(lambda m: m.group(1) + " " + value, text, count=1)
    if only_existing:
        return text
    return text.rstrip("\n") + "\n%s%s: %s\n" % (indent, key, value)


def drop_block(text, key):
    """トップレベルの「key:」と、その下の字下げされた行(入れ子)を消す。"""
    lines, out, skipping = text.split("\n"), [], False
    for ln in lines:
        if re.match(r"^%s:" % re.escape(key), ln):
            skipping = True
            continue
        if skipping and (ln.strip() == "" or ln[:1] in " \t" or ln.lstrip().startswith("#")) and not re.match(r"^\S", ln):
            continue
        skipping = False
        out.append(ln)
    return "\n".join(out)


def brand():
    ver = version()
    for desc in glob.glob(p("etc/calamares/branding/*/branding.desc")):
        t = read(desc)
        for key, val in (("productName", NAME), ("shortProductName", NAME),
                         ("versionedName", (NAME + " " + ver).strip()), ("shortVersionedName", (NAME + " " + ver).strip()),
                         ("bootloaderEntryName", NAME), ("version", ver), ("shortVersion", ver),
                         ("productUrl", '""'), ("supportUrl", '""'), ("knowledgeBaseUrl", '""'),
                         ("releaseNotesUrl", '""'), ("knownIssuesUrl", '""'), ("donateUrl", '""')):
            q = val if val.startswith('"') else '"%s"' % val
            t = set_scalar(t, key, q, indent="    ", only_existing=True)
        t = re.sub(r"Debian( GNU/Linux)?", NAME, t)             # ほかに残っている文字
        # ウィンドウを大きくする(既定の 800x520 だと、キーボード画面のテスト欄などが潰れる)
        t = set_scalar(t, "windowExpanding", "normal", only_existing=False)
        t = set_scalar(t, "windowSize", "1000px,680px", only_existing=False)
        write(desc, t)
        bdir = os.path.dirname(desc)
        # 入力欄が小さくなりすぎないよう、最小の大きさを決める(stylesheet.qss は、ブランドのフォルダにあれば自動で読まれる)
        qss = os.path.join(bdir, "stylesheet.qss")
        old_qss = read(qss) if os.path.exists(qss) else ""
        if "qwerty-os" not in old_qss:
            write(qss, old_qss + "\n/* qwerty-os: 入力欄の最小サイズ */\nQLineEdit { min-width: 280px; min-height: 28px; }\n")
        for q in glob.glob(os.path.join(bdir, "**", "*.qml"), recursive=True):     # スライドショーの文字
            try:
                write(q, re.sub(r"Debian( GNU/Linux)?", NAME, read(q)))
            except (OSError, UnicodeDecodeError):
                pass
        print("branding:", desc)


def modules():
    d = p("etc/calamares/modules")
    os.makedirs(d, exist_ok=True)
    # 所在地: 日本(東京)。GeoIP(ネットで場所を調べる)は使わない
    f = os.path.join(d, "locale.conf")
    t = read(f) if os.path.exists(f) else "---\n"
    t = drop_block(t, "geoip")
    t = set_scalar(t, "region", '"Asia"')
    t = set_scalar(t, "zone", '"Tokyo"')
    write(f, t)
    # ユーザー: 弱いパスワード(短い・同じ文字ばかり・辞書にある)でも進める。chek の既定は「進めない」
    f = os.path.join(d, "users.conf")
    t = read(f) if os.path.exists(f) else "---\n"
    t = drop_block(t, "passwordRequirements")
    t = drop_block(t, "allowWeakPasswords")
    t = drop_block(t, "allowWeakPasswordsDefault")
    t = t.rstrip("\n") + '''
passwordRequirements:
    minLength: -1
    maxLength: -1
    libpwquality:
        - minlen=0
        - minclass=0
        - dictcheck=0
        - usercheck=0
        - maxrepeat=0
        - maxsequence=0
allowWeakPasswords: true
allowWeakPasswordsDefault: true
'''
    t = set_scalar(t, "setRootPassword", "false")
    t = set_scalar(t, "sudoersGroup", "sudo")
    write(f, t)
    print("modules:", d)


def trim_step():
    """インストールのあと、OS 必須の機能だけを残す(ネットワーク接続・ブラウザーなどを外す)手順を、足す。"""
    d = p("etc/calamares/modules")
    os.makedirs(d, exist_ok=True)
    write(os.path.join(d, "shellprocess-qwerty-trim.conf"), """---
dontChroot: false
timeout: 900
verbose: true
script:
    - command: "/usr/lib/qwerty-os/qwerty-install-trim"
      timeout: 900
""")
    f = p("etc/calamares/settings.conf")
    if not os.path.exists(f):
        print("settings.conf が無い: 必須だけのインストールの手順を足せません")
        return
    t = read(f)
    if "shellprocess@qwerty-trim" in t:
        return
    inst = "    - id: qwerty-trim\n      module: shellprocess\n      config: shellprocess-qwerty-trim.conf\n"
    if re.search(r"^instances:\s*$", t, re.M):
        t = re.sub(r"^(instances:\s*\n)", lambda m: m.group(1) + inst, t, count=1, flags=re.M)
    else:
        t = re.sub(r"^(sequence:)", lambda m: "instances:\n" + inst + "\n" + m.group(1), t, count=1, flags=re.M)
    # exec の中の unpackfs の、すぐあとに足す(ブートローダーや initramfs より前)
    t2, n = re.subn(r"^(\s*-\s*unpackfs\s*\n)", lambda m: m.group(1) + m.group(1).replace("unpackfs", "shellprocess@qwerty-trim"), t, count=1, flags=re.M)
    if n == 0:
        print("settings.conf に unpackfs が見つからない: 手順を足せません")
        return
    write(f, t2)
    print("calamares: インストール後に、必須以外を外す手順を足しました")


if __name__ == "__main__":
    for fn in (brand, modules, trim_step):
        try:
            fn()
        except Exception as e:                  # ビルドは止めない
            print("calamares setup: %s で失敗: %r" % (fn.__name__, e))
