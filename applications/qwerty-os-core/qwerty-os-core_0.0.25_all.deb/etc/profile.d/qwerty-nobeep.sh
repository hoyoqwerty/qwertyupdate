# 端末・ログインのシェルで、ビープ音を鳴らさない
export LESS="${LESS:+$LESS }-Q"
if [ -t 1 ] && [ -z "${DISPLAY:-}" ] && command -v setterm >/dev/null 2>&1; then
    setterm -blength 0 2>/dev/null || true
fi
